// Организации (этап 5, шаг 5.1): модель. Организация по умолчанию есть; новый аккаунт становится её участником;
// один аккаунт может состоять в нескольких организациях; комната принадлежит организации; роли и статусы ограничены.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { storeForTest } from './helpers.js';
import { createMemoryStore } from '../src/store-memory.js';

const PEPPER = 'test-pepper-0123456789-0123456789-abcd';
const DEFAULT_ORG = 'org-default';
const ANNA = '@anna-org:inone.test';
const BORIS = '@boris-org:inone.test';

async function open() {
  const db = await storeForTest(PEPPER);
  const store = db?.store ?? createMemoryStore({ pinPepper: PEPPER });
  return { store, close: async () => { await db?.close(); } };
}

test('есть организация по умолчанию; новый аккаунт становится её участником', async () => {
  const { store, close } = await open();
  try {
    assert.equal(await store.addAccount(ANNA, 'hash-anna'), true);
    assert.equal(await store.orgRoleOf(DEFAULT_ORG, ANNA), 'member', 'участник организации по умолчанию');
    const orgs = await store.listUserOrgs(ANNA);
    assert.ok(orgs.some((o) => o.orgId === DEFAULT_ORG && o.status === 'approved'), 'организация по умолчанию одобрена');
  } finally {
    await close();
  }
});

test('один аккаунт может состоять в нескольких организациях, роли разные', async () => {
  const { store, close } = await open();
  try {
    await store.addAccount(ANNA, 'hash-anna');
    await store.createOrganization({ orgId: 'org-b', name: 'Вторая', status: 'approved', createdBy: ANNA, createdAt: 1 });
    assert.equal(await store.addOrgMember('org-b', ANNA, 'admin', 2), true);
    const orgs = await store.listUserOrgs(ANNA);
    assert.deepEqual(orgs.map((o) => [o.orgId, o.role]).sort(), [[DEFAULT_ORG, 'member'], ['org-b', 'admin']].sort(), 'два членства с разными ролями');
    assert.equal(await store.addOrgMember('org-b', ANNA, 'member', 3), false, 'повторное членство не создаётся');
  } finally {
    await close();
  }
});

test('комната принадлежит организации: по умолчанию — организация по умолчанию, можно указать другую', async () => {
  const { store, close } = await open();
  try {
    await store.addAccount(ANNA, 'hash-anna');
    await store.addAccount(BORIS, 'hash-boris');
    await store.createRoom('!org-room-1:inone.test', ANNA, [ANNA, BORIS], {});
    assert.equal(await store.roomOrg('!org-room-1:inone.test'), DEFAULT_ORG, 'комната по умолчанию в организации по умолчанию');
    await store.createOrganization({ orgId: 'org-c', name: 'Третья', status: 'pending', createdBy: BORIS, createdAt: 4 });
    await store.createRoom('!org-room-2:inone.test', BORIS, [BORIS], { orgId: 'org-c' });
    assert.equal(await store.roomOrg('!org-room-2:inone.test'), 'org-c', 'комната создана в указанной организации');
  } finally {
    await close();
  }
});

test('роли и статусы ограничены: неизвестная роль или статус не принимаются', async () => {
  const { store, close } = await open();
  try {
    await store.addAccount(ANNA, 'hash-anna');
    await store.addAccount(BORIS, 'hash-boris');
    await assert.rejects(async () => store.addOrgMember(DEFAULT_ORG, BORIS, 'superuser', 5), 'неизвестная роль отвергнута');
    await assert.rejects(async () => store.createOrganization({ orgId: 'org-d', name: 'Четвёртая', status: 'maybe', createdBy: ANNA, createdAt: 6 }), 'неизвестный статус отвергнут');
  } finally {
    await close();
  }
});
