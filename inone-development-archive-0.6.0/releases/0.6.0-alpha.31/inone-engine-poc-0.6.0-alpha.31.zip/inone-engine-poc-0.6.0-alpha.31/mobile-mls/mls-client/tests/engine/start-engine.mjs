// Запускает настоящий сервер движка на свободном порту для тестов клиента. Выход — по закрытию stdin.
// Путь к движку: переменная INONE_ENGINE_DIR; по умолчанию — папка engine рядом с mobile-mls.
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const engineDir = path.resolve(process.env.INONE_ENGINE_DIR ?? fileURLToPath(new URL('../../../..', import.meta.url)));
const { createServer } = await import(pathToFileURL(path.join(engineDir, 'src', 'server.js')).href);
const srv = createServer({ registrationMode: 'open', requirePhone: false, pinPepper: 'test-pepper-0123456789-0123456789-abcd' });
await new Promise((resolve) => srv.server.listen(0, '127.0.0.1', resolve));
console.log(`URL=http://127.0.0.1:${srv.server.address().port}`);
process.stdin.resume();
process.stdin.on('end', () => srv.server.close(() => process.exit(0)));
