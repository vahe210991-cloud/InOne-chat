//! Ядро клиента InOne на Rust: вход, ключевые пакеты, группы MLS, сообщения, догон после отсутствия,
//! вход нового устройства по подтверждению и удаление отозванных устройств из групп.
//! База устройства зашифрована (SQLCipher). Ключ передаёт платформа: Keychain на iOS, Keystore на Android.
use std::collections::{HashMap, HashSet};
use std::time::Duration;

use base64::{engine::general_purpose::STANDARD as B64, Engine};
use openmls::prelude::tls_codec::{Deserialize, Serialize};
use openmls::prelude::*;
use openmls_basic_credential::SignatureKeyPair;
use openmls_rust_crypto::RustCrypto;
use openmls_traits::random::OpenMlsRand;
use openmls_sqlite_storage::{Codec, Connection, SqliteStorageProvider};
use serde_json::{json, Value};

const CIPHERSUITE: Ciphersuite = Ciphersuite::MLS_128_DHKEMX25519_AES128GCM_SHA256_Ed25519;
/// Сколько прошлых эпох хранит группа (см. mls-bridge: по умолчанию OpenMLS не хранит ни одной).
const MAX_PAST_EPOCHS: usize = 16;

/// Что получено из комнаты при синхронизации.
#[derive(Debug, Clone, PartialEq)]
pub enum Incoming {
    Text { room_id: String, event_id: String, text: String },
    Unreadable { room_id: String, event_id: String },
}

/// Кодек хранилища OpenMLS: JSON.
#[derive(Default)]
pub struct JsonCodec;

impl Codec for JsonCodec {
    type Error = serde_json::Error;
    fn to_vec<T: serde::Serialize>(value: &T) -> Result<Vec<u8>, Self::Error> {
        serde_json::to_vec(value)
    }
    fn from_slice<T: serde::de::DeserializeOwned>(slice: &[u8]) -> Result<T, Self::Error> {
        serde_json::from_slice(slice)
    }
}

/// Провайдер OpenMLS устройства: криптография в памяти процесса, состояние групп — в зашифрованной базе.
pub struct DeviceProvider {
    crypto: RustCrypto,
    storage: SqliteStorageProvider<JsonCodec, Connection>,
}

impl OpenMlsProvider for DeviceProvider {
    type CryptoProvider = RustCrypto;
    type RandProvider = RustCrypto;
    type StorageProvider = SqliteStorageProvider<JsonCodec, Connection>;

    fn storage(&self) -> &Self::StorageProvider {
        &self.storage
    }
    fn crypto(&self) -> &Self::CryptoProvider {
        &self.crypto
    }
    fn rand(&self) -> &Self::RandProvider {
        &self.crypto
    }
}

struct Group {
    mls: MlsGroup,
    /// Эпоха, с которой устройство вошло в группу: более ранние сообщения оно не читает.
    join_epoch: u64,
}

pub struct Client {
    base: String,
    token: String,
    user_id: String,
    device_id: String,
    agent: ureq::Agent,
    provider: DeviceProvider,
    /// Соединение с той же базой для собственных таблиц клиента (комнаты, обработанные события, метаданные).
    meta: Connection,
    signer: SignatureKeyPair,
    credential: CredentialWithKey,
    groups: HashMap<String, Group>,
    processed: HashSet<String>,
    /// Сообщения, полученные при отправке из очереди: их забирает приложение через take_incoming().
    inbox: Vec<Incoming>,
}

fn text(e: impl std::fmt::Display) -> String {
    e.to_string()
}

fn hex_encode(bytes: &[u8]) -> String {
    bytes.iter().map(|b| format!("{b:02x}")).collect()
}

/// Открывает зашифрованную базу. Неверный ключ сразу даёт ошибку.
fn open_db(path: &str, key: &[u8; 32]) -> Result<Connection, String> {
    let conn = Connection::open(path).map_err(text)?;
    conn.pragma_update(None, "key", format!("x'{}'", hex_encode(key))).map_err(text)?;
    conn.query_row("SELECT count(*) FROM sqlite_master", [], |r| r.get::<_, i64>(0))
        .map_err(|_| "неверный ключ базы устройства или файл повреждён".to_string())?;
    Ok(conn)
}

fn request(agent: &ureq::Agent, base: &str, token: &str, method: &str, path: &str, body: Option<Value>) -> Result<Value, String> {
    let url = format!("{base}{path}");
    let mut req = agent.request(method, &url);
    if !token.is_empty() {
        req = req.set("authorization", &format!("Bearer {token}"));
    }
    let res = match body {
        Some(b) => req.send_json(b),
        None => req.call(),
    };
    match res {
        Ok(r) => r.into_json::<Value>().map_err(text),
        Err(ureq::Error::Status(code, r)) => Err(format!("{method} {path} -> {code} {}", r.into_string().unwrap_or_default())),
        Err(e) => Err(format!("сеть: {e}")),
    }
}

fn register(agent: &ureq::Agent, base: &str, user_id: &str, password: &str) -> Result<(), String> {
    match request(agent, base, "", "POST", "/register", Some(json!({ "userId": user_id, "password": password }))) {
        Ok(_) => Ok(()),
        Err(e) if e.contains("-> 409") => Ok(()),
        Err(e) => Err(e),
    }
}

/// Ключ базы устройства. Платформа хранит его в Keychain (iOS) или Keystore (Android); ядро его не сохраняет.
pub trait KeyStore {
    fn database_key(&self, scope: &str) -> Result<[u8; 32], String>;
}

/// Хранилище ключей в памяти: для тестов. Для выпуска нужно хранилище платформы.
#[derive(Default)]
pub struct MemoryKeyStore {
    keys: std::sync::Mutex<HashMap<String, [u8; 32]>>,
}

impl KeyStore for MemoryKeyStore {
    fn database_key(&self, scope: &str) -> Result<[u8; 32], String> {
        let mut keys = self.keys.lock().map_err(text)?;
        if let Some(key) = keys.get(scope) {
            return Ok(*key);
        }
        let key = RustCrypto::default().random_array::<32>().map_err(text)?;
        keys.insert(scope.to_string(), key);
        Ok(key)
    }
}

/// Ошибка временная (нет сети, 429, 5xx): её имеет смысл повторить позже.
pub fn is_retryable(err: &str) -> bool {
    if err.starts_with("сеть:") {
        return true;
    }
    if let Some(pos) = err.find(" -> ") {
        let code: String = err[pos + 4..].chars().take_while(|c| c.is_ascii_digit()).collect();
        if let Ok(code) = code.parse::<u16>() {
            return code == 429 || (500..600).contains(&code);
        }
    }
    false
}

const MAX_BACKOFF: Duration = Duration::from_secs(300);

/// Повторяет операцию при временных ошибках: паузы удваиваются, но не больше пяти минут.
pub fn with_retry<T>(attempts: u32, base: Duration, mut op: impl FnMut() -> Result<T, String>) -> Result<T, String> {
    let mut delay = base;
    let mut attempt = 1;
    loop {
        match op() {
            Ok(value) => return Ok(value),
            Err(e) if attempt < attempts && is_retryable(&e) => {
                std::thread::sleep(delay);
                delay = (delay * 2).min(MAX_BACKOFF);
                attempt += 1;
            }
            Err(e) => return Err(e),
        }
    }
}

/// Вход первого устройства аккаунта (или устройства, которое уже подтверждено).
pub fn connect(base: &str, user_id: &str, password: &str, device_id: &str, db_path: &str, keys: &dyn KeyStore) -> Result<Client, String> {
    let agent = ureq::AgentBuilder::new().build();
    register(&agent, base, user_id, password)?;
    let login = request(&agent, base, "", "POST", "/login", Some(json!({ "userId": user_id, "password": password, "deviceId": device_id })))?;
    let token = login["token"].as_str().ok_or("сервер не вернул токен: нужно подтверждение с другого устройства")?.to_string();
    build_client(agent, base, token, user_id, device_id, db_path, &keys.database_key(&format!("{user_id}/{device_id}"))?)
}

/// Вход нового устройства аккаунта: подтверждается существующим устройством `approver`.
pub fn connect_with_approval(
    base: &str,
    user_id: &str,
    password: &str,
    device_id: &str,
    db_path: &str,
    keys: &dyn KeyStore,
    approver: &Client,
) -> Result<Client, String> {
    let agent = ureq::AgentBuilder::new().build();
    register(&agent, base, user_id, password)?;
    let login = request(
        &agent,
        base,
        "",
        "POST",
        "/login",
        Some(json!({ "userId": user_id, "password": password, "deviceId": device_id, "label": device_id, "platform": "mobile" })),
    )?;
    let token = match login["token"].as_str() {
        Some(t) => t.to_string(),
        None => {
            let approval_id = login["approvalId"].as_str().ok_or("сервер не вернул запрос подтверждения")?.to_string();
            let code = login["code"].as_str().ok_or("нет кода подтверждения")?.to_string();
            let poll = login["pollSecret"].as_str().ok_or("нет секрета опроса")?.to_string();
            approver.call("POST", &format!("/approvals/{}/approve", urlencoding::encode(&approval_id)), Some(json!({ "code": code })))?;
            let mut token = None;
            for _ in 0..5 {
                let claim = request(
                    &agent,
                    base,
                    "",
                    "POST",
                    &format!("/approvals/{}/claim", urlencoding::encode(&approval_id)),
                    Some(json!({ "pollSecret": poll })),
                )?;
                match claim["status"].as_str() {
                    Some("approved") => {
                        token = claim["token"].as_str().map(String::from);
                        break;
                    }
                    Some("pending") => continue,
                    other => return Err(format!("вход отклонён: {other:?}")),
                }
            }
            token.ok_or("подтверждение входа не пришло")?
        }
    };
    build_client(agent, base, token, user_id, device_id, db_path, &keys.database_key(&format!("{user_id}/{device_id}"))?)
}

fn build_client(agent: ureq::Agent, base: &str, token: String, user_id: &str, device_id: &str, db_path: &str, db_key: &[u8; 32]) -> Result<Client, String> {
    let mut storage = SqliteStorageProvider::<JsonCodec, Connection>::new(open_db(db_path, db_key)?);
    storage.run_migrations().map_err(text)?;
    let provider = DeviceProvider { crypto: RustCrypto::default(), storage };
    let meta = open_db(db_path, db_key)?;
    meta.execute_batch(
        "CREATE TABLE IF NOT EXISTS client_meta (key TEXT PRIMARY KEY, value BLOB NOT NULL);
         CREATE TABLE IF NOT EXISTS client_rooms (room_id TEXT PRIMARY KEY, join_epoch INTEGER NOT NULL);
         CREATE TABLE IF NOT EXISTS client_processed (event_id TEXT PRIMARY KEY);
         CREATE TABLE IF NOT EXISTS client_outbox (local_id TEXT PRIMARY KEY, room_id TEXT NOT NULL, body TEXT NOT NULL, seq INTEGER NOT NULL);",
    )
    .map_err(text)?;

    let stored_public: Option<Vec<u8>> = meta
        .query_row("SELECT value FROM client_meta WHERE key = 'signer_public'", [], |r| r.get(0))
        .ok();
    let signer = match stored_public {
        Some(public) => SignatureKeyPair::read(provider.storage(), &public, CIPHERSUITE.signature_algorithm())
            .ok_or("ключ подписи устройства не найден в базе")?,
        None => {
            let signer = SignatureKeyPair::new(CIPHERSUITE.signature_algorithm()).map_err(text)?;
            signer.store(provider.storage()).map_err(text)?;
            meta.execute("INSERT INTO client_meta (key, value) VALUES ('signer_public', ?1)", [signer.to_public_vec()]).map_err(text)?;
            signer
        }
    };
    let credential = CredentialWithKey {
        credential: BasicCredential::new(format!("{user_id}/{device_id}").into_bytes()).into(),
        signature_key: signer.to_public_vec().into(),
    };

    let mut groups = HashMap::new();
    let mut stmt = meta.prepare("SELECT room_id, join_epoch FROM client_rooms").map_err(text)?;
    let rows: Vec<(String, i64)> = stmt
        .query_map([], |r| Ok((r.get(0)?, r.get(1)?)))
        .map_err(text)?
        .collect::<Result<_, _>>()
        .map_err(text)?;
    drop(stmt);
    for (room_id, join_epoch) in rows {
        let mls = MlsGroup::load(provider.storage(), &GroupId::from_slice(room_id.as_bytes()))
            .map_err(text)?
            .ok_or_else(|| format!("состояние группы {room_id} не найдено"))?;
        groups.insert(room_id, Group { mls, join_epoch: join_epoch as u64 });
    }
    let mut processed = HashSet::new();
    let mut stmt = meta.prepare("SELECT event_id FROM client_processed").map_err(text)?;
    for id in stmt.query_map([], |r| r.get::<_, String>(0)).map_err(text)? {
        processed.insert(id.map_err(text)?);
    }
    drop(stmt);

    Ok(Client {
        base: base.to_string(),
        token,
        user_id: user_id.to_string(),
        device_id: device_id.to_string(),
        agent,
        provider,
        meta,
        signer,
        credential,
        groups,
        processed,
        inbox: Vec::new(),
    })
}

impl Client {
    fn call(&self, method: &str, path: &str, body: Option<Value>) -> Result<Value, String> {
        request(&self.agent, &self.base, &self.token, method, path, body)
    }

    /// Идентификатор этого устройства на сервере.
    pub fn device_id(&self) -> &str {
        &self.device_id
    }

    fn mark_processed(&mut self, event_id: &str) -> Result<(), String> {
        self.meta.execute("INSERT OR IGNORE INTO client_processed (event_id) VALUES (?1)", [event_id]).map_err(text)?;
        self.processed.insert(event_id.to_string());
        Ok(())
    }

    /// Публикует ключевые пакеты этого устройства (не больше 50 за раз).
    pub fn upload_key_packages(&mut self, count: usize) -> Result<(), String> {
        let mut packages = Vec::with_capacity(count);
        for _ in 0..count {
            let bundle = KeyPackage::builder().build(CIPHERSUITE, &self.provider, &self.signer, self.credential.clone()).map_err(text)?;
            packages.push(B64.encode(bundle.key_package().tls_serialize_detached().map_err(text)?));
        }
        self.call("POST", "/mls/key-packages", Some(json!({ "packages": packages })))?;
        Ok(())
    }

    /// Публикует резервный ключевой пакет: им приглашают, когда обычные закончились.
    pub fn upload_last_resort(&mut self) -> Result<(), String> {
        let bundle = KeyPackage::builder().build(CIPHERSUITE, &self.provider, &self.signer, self.credential.clone()).map_err(text)?;
        let package = B64.encode(bundle.key_package().tls_serialize_detached().map_err(text)?);
        self.call("POST", "/mls/key-packages/last-resort", Some(json!({ "package": package })))?;
        Ok(())
    }

    /// Сколько обычных ключевых пакетов осталось на сервере для этого устройства.
    pub fn available_key_packages(&self) -> Result<u64, String> {
        let r = self.call("GET", "/mls/key-packages/count", None)?;
        r["available"].as_u64().ok_or_else(|| "сервер не вернул счётчик".to_string())
    }

    /// Доводит запас обычных пакетов до `target` и обновляет резервный пакет.
    pub fn ensure_key_packages(&mut self, target: u64) -> Result<(), String> {
        let have = self.available_key_packages()?;
        if have < target {
            let need = (target - have).min(50) as usize;
            self.upload_key_packages(need)?;
        }
        self.upload_last_resort()
    }

    /// Создаёт комнату на сервере и группу MLS на этом устройстве (эпоха 0).
    pub fn create_room(&mut self, room_id: &str) -> Result<(), String> {
        self.call("POST", "/rooms", Some(json!({ "roomId": room_id, "members": [self.user_id] })))?;
        let config = MlsGroupCreateConfig::builder()
            .ciphersuite(CIPHERSUITE)
            .use_ratchet_tree_extension(true)
            .max_past_epochs(MAX_PAST_EPOCHS)
            .build();
        let mls = MlsGroup::new_with_group_id(&self.provider, &self.signer, &config, GroupId::from_slice(room_id.as_bytes()), self.credential.clone()).map_err(text)?;
        self.meta.execute("INSERT OR REPLACE INTO client_rooms (room_id, join_epoch) VALUES (?1, 0)", [room_id]).map_err(text)?;
        self.groups.insert(room_id.to_string(), Group { mls, join_epoch: 0 });
        Ok(())
    }

    fn server_epoch(&self, room_id: &str) -> Result<u64, String> {
        let r = self.call("GET", &format!("/mls/groups/{}/epoch", urlencoding::encode(room_id)), None)?;
        r["epoch"].as_u64().ok_or_else(|| "сервер не вернул эпоху".to_string())
    }

    /// Приглашает пользователя: забирает его ключевые пакеты (все устройства), делает коммит и приветствия.
    pub fn invite(&mut self, room_id: &str, user_id: &str) -> Result<(), String> {
        let claimed = self.call("GET", &format!("/mls/key-packages/{}", urlencoding::encode(user_id)), None)?;
        let packages = claimed["packages"].as_array().ok_or("нет поля packages")?.clone();
        if packages.is_empty() {
            return Err(format!("у {user_id} нет ключевых пакетов"));
        }
        let mut key_packages = Vec::with_capacity(packages.len());
        let mut devices = Vec::with_capacity(packages.len());
        for p in &packages {
            let bytes = B64.decode(p["package"].as_str().ok_or("пакет не строка")?).map_err(text)?;
            let kp = KeyPackageIn::tls_deserialize_exact(&bytes).map_err(text)?.validate(self.provider.crypto(), ProtocolVersion::Mls10).map_err(text)?;
            key_packages.push(kp);
            devices.push(p["deviceId"].as_str().ok_or("нет deviceId")?.to_string());
        }
        let (epoch_before, commit_b64, welcome_b64) = {
            let group = self.groups.get_mut(room_id).ok_or("комната не создана на этом устройстве")?;
            let epoch_before = group.mls.epoch().as_u64();
            let (commit, welcome, _) = group.mls.add_members(&self.provider, &self.signer, &key_packages).map_err(text)?;
            group.mls.merge_pending_commit(&self.provider).map_err(text)?;
            (epoch_before, B64.encode(commit.tls_serialize_detached().map_err(text)?), B64.encode(welcome.tls_serialize_detached().map_err(text)?))
        };
        let welcomes: Vec<Value> = devices.iter().map(|d| json!({ "userId": user_id, "deviceId": d, "welcome": welcome_b64 })).collect();
        self.call(
            "POST",
            &format!("/mls/groups/{}/commits", urlencoding::encode(room_id)),
            Some(json!({ "epoch": epoch_before, "commit": commit_b64, "changes": { "adds": [user_id], "removes": [] }, "welcomes": welcomes })),
        )?;
        Ok(())
    }

    /// Отправляет текст в комнату. Устройство должно быть на эпохе сервера: иначе сначала синхронизация.
    /// Отправляет текст в комнату. Устройство должно быть на эпохе сервера: иначе сначала синхронизация.
    pub fn send_text(&mut self, room_id: &str, plaintext: &str) -> Result<String, String> {
        let id = hex_encode(&self.provider.rand().random_vec(16).map_err(text)?);
        self.send_text_with_id(room_id, plaintext, &id)
    }

    /// Отправляет текст с идентификатором клиента: повтор с тем же идентификатором не создаёт дубля.
    pub fn send_text_with_id(&mut self, room_id: &str, plaintext: &str, client_message_id: &str) -> Result<String, String> {
        let server = self.server_epoch(room_id)?;
        let body = {
            let group = self.groups.get_mut(room_id).ok_or("комната не создана на этом устройстве")?;
            let local = group.mls.epoch().as_u64();
            if local != server {
                return Err(format!("устройство на эпохе {local}, сервер на {server}: сначала синхронизация"));
            }
            let message = group.mls.create_message(&self.provider, &self.signer, plaintext.as_bytes()).map_err(text)?;
            B64.encode(message.tls_serialize_detached().map_err(text)?)
        };
        let res = self.call(
            "POST",
            &format!("/mls/groups/{}/messages", urlencoding::encode(room_id)),
            Some(json!({ "message": body, "kind": "text", "forwarded": false, "clientMessageId": client_message_id })),
        )?;
        let event_id = res["event_id"].as_str().ok_or("сервер не вернул event_id")?.to_string();
        self.mark_processed(&event_id)?;
        Ok(event_id)
    }

    /// Входит в группы по приветствиям, которые ждут на сервере, и подтверждает их.
    fn join_welcomes(&mut self) -> Result<(), String> {
        let pending = self.call("GET", "/mls/welcomes", None)?;
        for w in pending["welcomes"].as_array().cloned().unwrap_or_default() {
            let id = w["id"].as_i64().ok_or("нет id приветствия")?;
            let bytes = B64.decode(w["welcome"].as_str().ok_or("приветствие не строка")?).map_err(text)?;
            let welcome = match MlsMessageIn::tls_deserialize_exact(&bytes).map_err(text)?.extract() {
                MlsMessageBodyIn::Welcome(x) => x,
                _ => return Err("ожидалось приветствие".to_string()),
            };
            let join_config = MlsGroupJoinConfig::builder().use_ratchet_tree_extension(true).max_past_epochs(MAX_PAST_EPOCHS).build();
            let staged = StagedWelcome::new_from_welcome(&self.provider, &join_config, welcome, None).map_err(text)?;
            let mls = staged.into_group(&self.provider).map_err(text)?;
            let room_id = String::from_utf8_lossy(mls.group_id().as_slice()).to_string();
            let join_epoch = mls.epoch().as_u64();
            self.meta.execute("INSERT OR REPLACE INTO client_rooms (room_id, join_epoch) VALUES (?1, ?2)", (&room_id, join_epoch as i64)).map_err(text)?;
            self.groups.insert(room_id, Group { mls, join_epoch });
            self.call("POST", &format!("/mls/welcomes/{id}/ack"), Some(json!({})))?;
        }
        Ok(())
    }

    /// Читает комнату: сообщения идут по эпохам, коммит N -> N+1 применяется после сообщений эпохи N.
    fn sync_room(&mut self, room_id: &str, out: &mut Vec<Incoming>) -> Result<(), String> {
        let events = self.call("GET", &format!("/rooms/{}/events", urlencoding::encode(room_id)), None)?;
        let mut pending: Vec<(u64, String, Vec<u8>)> = Vec::new();
        for ev in events["events"].as_array().cloned().unwrap_or_default() {
            let Some(mls_b64) = ev["content"]["mls"].as_str() else { continue };
            let event_id = ev["event_id"].as_str().unwrap_or_default().to_string();
            if self.processed.contains(&event_id) {
                continue;
            }
            let bytes = B64.decode(mls_b64).map_err(text)?;
            let protocol = MlsMessageIn::tls_deserialize_exact(&bytes).map_err(text)?.try_into_protocol_message().map_err(text)?;
            pending.push((protocol.epoch().as_u64(), event_id, bytes));
        }
        let current = self.groups.get(room_id).ok_or("комната не создана на этом устройстве")?.mls.epoch().as_u64();
        let commits = self.call("GET", &format!("/mls/groups/{}/commits?since={current}", urlencoding::encode(room_id)), None)?;
        let commits: Vec<(u64, Vec<u8>)> = commits["commits"]
            .as_array()
            .cloned()
            .unwrap_or_default()
            .iter()
            .map(|c| Ok((c["epoch"].as_u64().ok_or("нет эпохи")?, B64.decode(c["commit"].as_str().ok_or("коммит не строка")?).map_err(text)?)))
            .collect::<Result<_, String>>()?;

        let join_epoch = self.groups[room_id].join_epoch;
        let before_join: Vec<String> = pending.iter().filter(|(e, _, _)| *e < join_epoch).map(|(_, id, _)| id.clone()).collect();
        for event_id in before_join {
            self.mark_processed(&event_id)?;
        }
        loop {
            let epoch = self.groups[room_id].mls.epoch().as_u64();
            let ready: Vec<(String, Vec<u8>)> = pending
                .iter()
                .filter(|(e, id, _)| *e == epoch && !self.processed.contains(id))
                .map(|(_, id, b)| (id.clone(), b.clone()))
                .collect();
            for (event_id, bytes) in ready {
                let protocol = MlsMessageIn::tls_deserialize_exact(&bytes).map_err(text)?.try_into_protocol_message().map_err(text)?;
                let group = self.groups.get_mut(room_id).ok_or("комната не создана на этом устройстве")?;
                match group.mls.process_message(&self.provider, protocol) {
                    Ok(processed) => match processed.into_content() {
                        ProcessedMessageContent::ApplicationMessage(app) => out.push(Incoming::Text {
                            room_id: room_id.to_string(),
                            event_id: event_id.clone(),
                            text: String::from_utf8(app.into_bytes()).map_err(text)?,
                        }),
                        _ => out.push(Incoming::Unreadable { room_id: room_id.to_string(), event_id: event_id.clone() }),
                    },
                    Err(_) => out.push(Incoming::Unreadable { room_id: room_id.to_string(), event_id: event_id.clone() }),
                }
                self.mark_processed(&event_id)?;
            }
            let Some((_, commit)) = commits.iter().find(|(e, _)| *e == epoch + 1) else { break };
            let protocol = MlsMessageIn::tls_deserialize_exact(commit).map_err(text)?.try_into_protocol_message().map_err(text)?;
            let group = self.groups.get_mut(room_id).ok_or("комната не создана на этом устройстве")?;
            let processed = group.mls.process_message(&self.provider, protocol).map_err(text)?;
            match processed.into_content() {
                ProcessedMessageContent::StagedCommitMessage(staged) => {
                    group.mls.merge_staged_commit(&self.provider, *staged).map_err(text)?;
                }
                _ => return Err("ожидался коммит".to_string()),
            }
        }
        Ok(())
    }

    /// Полная синхронизация: вход по приветствиям и чтение всех комнат устройства.
    pub fn sync(&mut self) -> Result<Vec<Incoming>, String> {
        self.join_welcomes()?;
        let rooms: Vec<String> = self.groups.keys().cloned().collect();
        let mut out = Vec::new();
        for room in rooms {
            self.sync_room(&room, &mut out)?;
        }
        Ok(out)
    }

    /// Ставит текст в очередь отправки: он уйдёт, когда появится связь. Возвращает локальный номер.
    pub fn enqueue_text(&mut self, room_id: &str, plaintext: &str) -> Result<String, String> {
        let local_id = hex_encode(&self.provider.rand().random_vec(16).map_err(text)?);
        self.meta
            .execute(
                "INSERT INTO client_outbox (local_id, room_id, body, seq) VALUES (?1, ?2, ?3, (SELECT COALESCE(MAX(seq), 0) + 1 FROM client_outbox))",
                (&local_id, room_id, plaintext),
            )
            .map_err(text)?;
        Ok(local_id)
    }

    /// Сколько сообщений ждут отправки.
    pub fn outbox_len(&self) -> Result<u64, String> {
        let n: i64 = self.meta.query_row("SELECT COUNT(*) FROM client_outbox", [], |r| r.get(0)).map_err(text)?;
        Ok(n as u64)
    }

    /// Отправляет очередь по порядку. Без связи ничего не теряет: возвращает 0, очередь остаётся.
    pub fn flush_outbox(&mut self) -> Result<usize, String> {
        let items: Vec<(String, String, String)> = {
            let mut stmt = self.meta.prepare("SELECT local_id, room_id, body FROM client_outbox ORDER BY seq").map_err(text)?;
            let rows = stmt.query_map([], |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?))).map_err(text)?;
            rows.collect::<Result<_, _>>().map_err(text)?
        };
        if items.is_empty() {
            return Ok(0);
        }
        match self.sync() {
            Ok(got) => self.inbox.extend(got),
            Err(e) if is_retryable(&e) => return Ok(0),
            Err(e) => return Err(e),
        }
        let mut sent = 0;
        for (local_id, room_id, body) in items {
            match self.send_text_with_id(&room_id, &body, &local_id) {
                Ok(_) => {
                    self.meta.execute("DELETE FROM client_outbox WHERE local_id = ?1", [&local_id]).map_err(text)?;
                    sent += 1;
                }
                Err(e) if is_retryable(&e) => break,
                Err(e) => return Err(e),
            }
        }
        Ok(sent)
    }

    /// Забирает сообщения, которые пришли при синхронизации из очереди отправки.
    pub fn take_incoming(&mut self) -> Vec<Incoming> {
        std::mem::take(&mut self.inbox)
    }

    /// Синхронизация с повторами: при сбоях сети ждёт всё дольше, но не дольше `attempts` попыток.
    pub fn sync_retrying(&mut self, attempts: u32, base: Duration) -> Result<Vec<Incoming>, String> {
        with_retry(attempts, base, || self.sync())
    }

    /// Эпоха, которую знает устройство, для комнаты.
    pub fn local_epoch(&self, room_id: &str) -> Option<u64> {
        self.groups.get(room_id).map(|g| g.mls.epoch().as_u64())
    }

    /// Участники группы по их устройствам (`пользователь/устройство`).
    pub fn members_of(&self, room_id: &str) -> Result<Vec<String>, String> {
        let group = self.groups.get(room_id).ok_or("комната не создана на этом устройстве")?;
        Ok(group.mls.members().map(|m| String::from_utf8_lossy(m.credential.serialized_content()).to_string()).collect())
    }

    /// Отзывает устройство аккаунта на сервере: его сессии перестают работать.
    pub fn revoke_device(&self, device_id: &str) -> Result<(), String> {
        self.call("DELETE", &format!("/devices/{}", urlencoding::encode(device_id)), None)?;
        Ok(())
    }

    /// Сколько отозванных устройств ещё стоят в группах и ждут удаления.
    pub fn pending_removals(&self) -> Result<usize, String> {
        let r = self.call("GET", "/mls/removals", None)?;
        Ok(r["removals"].as_array().map(|a| a.len()).unwrap_or(0))
    }

    /// Удаляет из групп отозванные устройства: коммит удаляет их листья и объявляет удаление на сервере.
    pub fn remove_revoked_devices(&mut self) -> Result<usize, String> {
        let removals = self.call("GET", "/mls/removals", None)?;
        let mut by_room: HashMap<String, Vec<String>> = HashMap::new();
        for r in removals["removals"].as_array().cloned().unwrap_or_default() {
            let room = r["roomId"].as_str().ok_or("нет roomId")?.to_string();
            let device = r["deviceId"].as_str().ok_or("нет deviceId")?.to_string();
            by_room.entry(room).or_default().push(device);
        }
        let mut removed = 0;
        for (room_id, devices) in by_room {
            if !self.groups.contains_key(&room_id) {
                continue;
            }
            let server = self.server_epoch(&room_id)?;
            let identities: Vec<Vec<u8>> = devices.iter().map(|d| format!("{}/{}", self.user_id, d).into_bytes()).collect();
            let (epoch_before, commit_b64) = {
                let group = self.groups.get_mut(&room_id).ok_or("комната не найдена")?;
                let local = group.mls.epoch().as_u64();
                if local != server {
                    return Err(format!("устройство на эпохе {local}, сервер на {server}: сначала синхронизация"));
                }
                let leaves: Vec<LeafNodeIndex> = group
                    .mls
                    .members()
                    .filter(|m| identities.iter().any(|id| m.credential.serialized_content() == id.as_slice()))
                    .map(|m| m.index)
                    .collect();
                let commit = if leaves.is_empty() {
                    let bundle = group.mls.self_update(&self.provider, &self.signer, LeafNodeParameters::default()).map_err(text)?;
                    bundle.commit().clone()
                } else {
                    let (commit, _, _) = group.mls.remove_members(&self.provider, &self.signer, &leaves).map_err(text)?;
                    commit
                };
                group.mls.merge_pending_commit(&self.provider).map_err(text)?;
                (local, B64.encode(commit.tls_serialize_detached().map_err(text)?))
            };
            self.call(
                "POST",
                &format!("/mls/groups/{}/commits", urlencoding::encode(&room_id)),
                Some(json!({ "epoch": epoch_before, "commit": commit_b64, "changes": { "adds": [], "removes": [], "removeDevices": devices } })),
            )?;
            removed += devices.len();
        }
        Ok(removed)
    }
}

#[cfg(test)]
mod retry_tests {
    use super::*;

    #[test]
    fn network_and_server_errors_are_retried_client_errors_are_not() {
        assert!(is_retryable("сеть: connection refused"));
        assert!(is_retryable("GET /x -> 503 unavailable"));
        assert!(is_retryable("POST /y -> 429 slow down"));
        assert!(!is_retryable("GET /x -> 401 unauthorized"));
        assert!(!is_retryable("POST /z -> 409 conflict"));
        assert!(!is_retryable("неизвестная ошибка"));
    }

    #[test]
    fn retry_stops_on_success_and_on_fatal_errors() {
        let mut calls = 0;
        let ok: Result<u32, String> = with_retry(5, Duration::ZERO, || {
            calls += 1;
            if calls < 3 { Err("сеть: нет связи".to_string()) } else { Ok(calls) }
        });
        assert_eq!(ok, Ok(3));
        let mut calls = 0;
        let fatal: Result<(), String> = with_retry(5, Duration::ZERO, || {
            calls += 1;
            Err("GET /x -> 401 нет доступа".to_string())
        });
        assert!(fatal.is_err());
        assert_eq!(calls, 1, "ошибка доступа не повторяется");
        let mut calls = 0;
        let gave_up: Result<(), String> = with_retry(3, Duration::ZERO, || {
            calls += 1;
            Err("сеть: нет связи".to_string())
        });
        assert!(gave_up.is_err());
        assert_eq!(calls, 3, "не больше заданного числа попыток");
    }
}
