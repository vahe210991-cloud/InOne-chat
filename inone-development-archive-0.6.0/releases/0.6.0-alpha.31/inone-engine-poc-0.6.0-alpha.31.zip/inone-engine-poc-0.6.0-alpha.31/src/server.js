// ============================================================================
// ВРЕМЕННЫЙ сервер для проверки протокола. Всё хранится в памяти.
// Для продакшена нужны PostgreSQL, TLS, настоящая почта и SMS, журналирование.
//
// Что проверяется здесь:
//  - вход по паролю; токен привязан к устройству;
//  - вход с нового устройства подтверждается кодом с существующего устройства;
//  - PIN: хранится хэшем с секретным перцем, блокируется после неверных попыток;
//  - отключение устройства: его токены и ключи перестают работать;
//  - восстановление после кражи: код на почте, задержка 48 часов,
//    отмена с любого устройства, PIN (если задан), отключение всех устройств;
//  - в беседах принимаются только зашифрованные события.
// ============================================================================
import { parseKeyPackages, parseCommitRequest, parseApplicationRequest, MLS_UNUSED_MAX } from './mls-rules.js';
import { readPrivateMessageHeader } from './mls-wire.js';
import { normalizeRoomName } from './room-names.js';
import { hashPassword, checkPassword, MIN_PASSWORD_LENGTH, newUserId } from './account-rules.js';
import { ALLOWED_CONTENT_TYPES, MAX_STICKERS_PER_GROUP, assetMatchesVisibility, assetVisibleTo, createAssetId, validateAppearance, validateAssetUpload } from './group-appearance.js';
import QRCode from 'qrcode';
import { createInviteId, createInviteToken, hashInviteToken, inviteUsable, validateInviteOptions } from './room-rules.js';
import { deleteWindowClosed, editWindowClosed, readByOthers, validateRoomSettings } from './room-rules.js';
import { MESSAGE_KINDS, effectiveCapabilities, hasCapability, normalizeCapabilities } from './room-permissions.js';
import http from 'node:http';
import { createHash, createHmac, randomBytes, randomInt, randomUUID, scryptSync, timingSafeEqual, createPublicKey, createVerify } from 'node:crypto';
import { createMemoryStore } from './store-memory.js';
import { LOGIN_POLICY } from './login-throttle.js';
import { windowOpen, requestCode, confirmLink, checkCode, completeRecovery, cancelWindow, issueIdentity, checkIdentity, closeWindowIfDue } from './recovery-rules.js';
import { createMemorySms } from './sms.js';
import { isPhone, requestPhoneCode, checkPhoneCode } from './phone-rules.js';
import { normalizePhone } from './phone-international.js';
import { DEFAULT_RATE_LIMITS } from './rate-limit.js';
import { normalizeEmail, isEmail, validateNickname } from './identity-rules.js';
import { requestEmailCode, checkEmailCode, useEmailToken } from './email-code-rules.js';
import { createProviderVerifier, fetchProviderKeys } from './provider-auth.js';

export const RECOVERY_DELAY_MS = 48 * 60 * 60 * 1000;
// POST, разрешённые в окне восстановления: чтение чужих ключей и отмена (право отмены проверяет маршрут, D8).
const WINDOW_POST_OK = new Set(['/keys/query', '/recovery/cancel']);
export const APPROVAL_TTL_MS = 10 * 60 * 1000;
export const MAX_APPROVAL_CODE_ATTEMPTS = 3;
export const MAX_PENDING_APPROVALS = 3;
export const FREE_PIN_ATTEMPTS = 5;
export const TO_DEVICE_TTL_MS = 30 * 24 * 60 * 60 * 1000; // недоставленная очередь хранится не дольше 30 дней (спецификация)
const SEND_DEDUP_MS = 7 * 24 * 60 * 60 * 1000;             // повтор отправки с тем же номером считается дублем 7 дней
const MAX_LOCK_MS = 24 * 60 * 60 * 1000;

const sha = (v) => createHash('sha256').update(v).digest('hex');
/** Ключевой хэш (HMAC с секретным перцем). Без перца значение из базы не проверить и не подобрать (C-08). */
const keyedHash = (pepper, label, value) => createHmac('sha256', pepper).update(`${label}|${value}`).digest('hex');
const sameHex = (a, b) => {
  const x = Buffer.from(a, 'hex');
  const y = Buffer.from(b, 'hex');
  return x.length === y.length && timingSafeEqual(x, y);
};

/** Длительность блокировки PIN: 1, 2, 4… минуты, не больше суток. */
export function lockDurationMs(attempt) {
  const steps = Math.max(0, attempt - FREE_PIN_ATTEMPTS);
  return Math.min(MAX_LOCK_MS, 60_000 * 2 ** Math.min(steps, 20));
}

/** Слабый PIN не принимается. Логика та же, что в основном проекте (pin-lock.service.ts). */
export function weakPinReason(pin) {
  if (!/^\d+$/.test(pin)) return 'PIN must contain digits only';
  if (pin.length < 6 || pin.length > 12) return 'PIN must be 6-12 digits';
  if (/^(\d)\1+$/.test(pin)) return 'PIN is too simple (one repeated digit)';
  const d = [...pin].map(Number);
  const step = d[1] - d[0];
  if ((step === 1 || step === -1) && d.every((x, i) => i === 0 || x - d[i - 1] === step)) {
    return 'PIN is too simple (a straight run of digits)';
  }
  for (let size = 2; size <= pin.length / 2; size++) {
    if (pin.length % size === 0 && pin === pin.slice(0, size).repeat(pin.length / size)) {
      return 'PIN is too simple (a repeating pattern)';
    }
  }
  return null;
}





// Фиктивный хэш для неизвестных логинов: проверка занимает то же время, что и для настоящих (C-04).
const DUMMY_PASSWORD_HASH = hashPassword(randomBytes(16).toString('hex'));

// PIN: сначала HMAC с секретным перцем (он лежит в окружении, не в базе), потом scrypt.
// Так утёкшая база сама по себе не позволяет перебрать PIN.
const pepperedPin = (pepper, pin) => createHmac('sha256', pepper).update(pin).digest();
function hashPin(pepper, pin) {
  const salt = randomBytes(16);
  return `${salt.toString('base64')}$${scryptSync(pepperedPin(pepper, pin), salt, 32).toString('base64')}`;
}
function checkPin(pepper, pin, stored) {
  const [saltB64, hashB64] = stored.split('$');
  const expected = Buffer.from(hashB64, 'base64');
  const actual = scryptSync(pepperedPin(pepper, pin), Buffer.from(saltB64, 'base64'), 32);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

// Страница подтверждения восстановления: открытие ссылки ничего не меняет, подтверждает только кнопка (POST).
const escapeHtml = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const htmlPage = (title, bodyHtml) =>
  `<!doctype html><html lang="ru"><head><meta charset="utf-8"><title>${escapeHtml(title)}</title></head><body><h1>${escapeHtml(title)}</h1>${bodyHtml}</body></html>`;

export function createServer({ pinPepper, mailer: externalMailer, store, trustProxy = false, sms, requirePhone = false, registrationMode = 'verified', providers = {}, providerKeysSource = null, publicUrl = 'https://inone.test', rateLimits = {}, bodyLimit = 4 * 1024 * 1024, logger = null, wireLogLimit = 2000, smsEnabled = true, phoneBlockedCountries = [], phoneAllowedCountries = [], devEmailCode = '' } = {}) {
  // Аккаунты и PIN: в базе (store.js) или в памяти по умолчанию (store-memory.js).
  const storage = store ?? createMemoryStore({ pinPepper });
  // SMS-поставщик подключается снаружи; по умолчанию сообщения складываются в список (для тестов).
  const smsSender = sms ?? createMemorySms();
  // Лимиты запросов (D5): регистрация с адреса, восстановление с адреса, SMS на один номер. Окна хранятся в базе.
  const limitTable = { ...DEFAULT_RATE_LIMITS, ...rateLimits };
  const checkRate = async (name, key) => {
    let allowed = true;
    let retryAt = null;
    for (const { windowMs, limit } of limitTable[name]) {
      const hit = await storage.rateHit(`${name}|${key}|${windowMs}`, now(), windowMs, limit);
      if (!hit.allowed) {
        allowed = false;
        retryAt = retryAt === null ? hit.retryAt : Math.max(retryAt, hit.retryAt);
      }
    }
    return { allowed, retryAt };
  };
  // Адрес источника. За обратным прокси берём адрес из X-Forwarded-For, только если сервер за прокси (D7).
  const clientIp = (req) => {
    const forwarded = trustProxy ? String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() : '';
    return forwarded || req.socket.remoteAddress || 'unknown';
  };
  if (!pinPepper || pinPepper.length < 32) {
    // Без перца сервер не запускается: иначе PIN легко перебрать после утечки базы.
    throw new Error('PIN_PEPPER обязателен и не короче 32 символов');
  }

  let offset = 0;                                  // сдвиг часов для тестов
  // Правило App Store 4.8: если предложен вход через Google, обязателен и Sign in with Apple.
  if (providers.google?.clientIds?.length && !providers.apple?.clientIds?.length) {
    throw new Error('Sign in with Apple must be enabled together with Google sign-in (App Store guideline 4.8)');
  }
  const verifyProviderToken = createProviderVerifier({
    providers,
    keysSource: providerKeysSource ?? fetchProviderKeys,
    nowMs: () => now(),
  });
  const now = () => Date.now() + offset;

  const outbox = [];               // письма (в продакшене — почтовый сервис)
  const wireLog = [];              // что пришло на сервер, с замазанными секретами
  let pinChecks = 0;               // сколько раз реально проверяли PIN (для теста перебора)

  const key = (u, d) => `${u}|${d}`;
  const send = (res, status, obj) => {
    res.writeHead(status, { 'content-type': 'application/json', 'x-content-type-options': 'nosniff', 'cache-control': 'no-store', 'referrer-policy': 'no-referrer' });
    res.end(JSON.stringify(obj));
  };
  // Устройства лежат в хранилище. Сервер не знает, с каким устройством какой собеседник общается,
  // поэтому сообщает всем активным устройствам, что список устройств изменился.
  const markChanged = async (userId) => {
    for (const rec of await storage.activeDevices()) {
      await storage.enqueue(key(rec.userId, rec.deviceId), 'device_list', { userId }, userId, now() + TO_DEVICE_TTL_MS);
    }
  };
  const markRoomChanged = async (roomId, userIds) => {
    for (const rec of await storage.activeDevices()) {
      if (userIds.includes(rec.userId)) await storage.enqueue(key(rec.userId, rec.deviceId), 'room', { roomId }, roomId, now() + TO_DEVICE_TTL_MS);
    }
  };
  const alertDevices = async (userId, content) => {
    for (const rec of await storage.devicesOfUser(userId)) {
      if (!rec.revoked) await storage.enqueue(key(rec.userId, rec.deviceId), 'security', { body: content }, null, now() + TO_DEVICE_TTL_MS);
    }
  };
  // Отправитель писем подключается снаружи. В разработке и тестах письма складываются в список.
  const mailer = externalMailer ?? { send: async (m) => { outbox.push(m); } };
  const mailTo = (to, subject, text) => mailer.send({ to, subject, text });
  // Письмо владельцу аккаунта — на подтверждённую почту. У аккаунтов без профиля адресом остаётся идентификатор.
  const mail = async (userId, subject, text) => {
    const profile = await storage.profileGet(userId);
    // Служебные письма — на основную почту и, если она задана, на запасную.
    const backup = await storage.backupEmailGet(userId);
    await mailTo(profile?.email ?? userId, subject, text);
    if (backup) await mailTo(backup.email, subject, text);
  };
  const revokeDevice = async (rec) => {
    await storage.revokeDevice(key(rec.userId, rec.deviceId));
    // Отозванное устройство больше не выдаётся как получатель ключевых пакетов и приветствий.
    await storage.mlsDropDevicePackages(rec.userId, rec.deviceId);
    await storage.mlsRecordDeviceRemovals(rec.userId, rec.deviceId, now());
  };
  // Код восстановления хранится только как ключевой хэш; сам код есть лишь в письме (C-08).
  const recoveryCodeHash = (userId, code) => keyedHash(pinPepper, `recovery:${userId}`, code);
  const phoneCodeHash = (userId, code) => keyedHash(pinPepper, `phone:${userId}`, code);
  const recoveryLinkHash = (userId, token) => keyedHash(pinPepper, `recovery-link:${userId}`, token);
  const recoveryCancelHash = (userId, code) => keyedHash(pinPepper, `recovery-cancel:${userId}`, code);
  // Почтовые коды регистрации хранятся только как ключевые хэши; сам код есть лишь в письме.
  const emailCodeHash = (email, code) => keyedHash(pinPepper, `email-code:${email}`, code);
  const emailTokenHash = (email, token) => keyedHash(pinPepper, `email-token:${email}`, token);
  // Внутренний идентификатор аккаунта случайный и непубличный: почта и никнейм его не содержат.
  // Подтверждение действий над провайдерами (этап 2, решения владельца): пока пароль активен — пароль;
  // после привязки Google или Apple пароль отключён полностью — подтверждение кодом с почты, привязанным к действию.
  const STEPUP_ACTIONS = ['link-provider', 'remove-provider', 'set-backup-email', 'remove-backup-email', 'enable-biometric', 'disable-biometric'];
  const stepupActionText = {
    'link-provider': 'привязка аккаунта Google или Apple',
    'remove-provider': 'отвязка аккаунта Google или Apple',
    'set-backup-email': 'добавление или смена запасной почты',
    'remove-backup-email': 'удаление запасной почты',
    'enable-biometric': 'включение подтверждения Face ID или Touch ID',
    'disable-biometric': 'отключение подтверждения Face ID или Touch ID',
  };
  const stepupKey = (userId) => `stepup|${userId}`;
  const stepupCodeHash = (userId, action, code) => keyedHash(pinPepper, `stepup-code:${userId}:${action}`, code);
  const stepupTokenHash = (userId, action, token) => keyedHash(pinPepper, `stepup-token:${userId}:${action}`, token);
  // Пароль принимается, только пока аккаунт не привязан к внешнему провайдеру.
  const passwordSignInAllowed = async (userId) => (await storage.providerLinksOf(userId)).length === 0;
  const verifyStepUp = async (userId, action, body, deviceId = null) => {
    // Биометрический грант (этап 2б): одноразовый, только для своего действия и своего устройства.
    if (typeof body.bioGrant === 'string' && body.bioGrant !== '') {
      return (await consumeBioGrant(userId, action, body.bioGrant, deviceId)) ? { ok: true } : { ok: false, status: 403, error: 'biometric confirmation invalid' };
    }
    if (await passwordSignInAllowed(userId)) {
      const stored = await storage.accountHash(userId);
      if (typeof body.password === 'string' && checkPassword(body.password, stored)) return { ok: true };
      return { ok: false, status: 403, error: 'password required' };
    }
    const token = typeof body.stepupToken === 'string' ? body.stepupToken : '';
    if (token === '') return { ok: false, status: 403, error: 'email confirmation required' };
    const used = await storage.emailCodeUpdate(stepupKey(userId), (e) => {
      const out = useEmailToken(e, {
        nowMs: now(),
        tokenOk: !!e.tokenHash && sameHex(stepupTokenHash(userId, action, token), e.tokenHash),
      });
      return { next: out.next, result: out.outcome };
    });
    if (used === 'ok') return { ok: true };
    if (used === 'expired') return { ok: false, status: 410, error: 'confirmation expired' };
    return { ok: false, status: 403, error: 'confirmation invalid' };
  };
  // Отложенный вход (решение владельца): аккаунт без активных устройств, только почта — 48 часов;
  // аккаунт с привязкой Google или Apple — сразу.
  const DEVICE_WAIT_MS = 48 * 60 * 60 * 1000;
  const deviceWaitCodeHash = (userId, deviceId, code) => keyedHash(pinPepper, `device-wait:${userId}:${deviceId}`, code);
  // Запасная почта (решение владельца): необязательна; коды подтверждения действий идут на неё, если она задана.
  const backupKey = (userId, email) => `backup|${userId}|${email}`;
  const backupCodeHash = (userId, email, code) => keyedHash(pinPepper, `backup-code:${userId}:${email}`, code);
  const confirmationEmail = async (userId) => {
    const backup = await storage.backupEmailGet(userId);
    if (backup) return backup.email;
    return (await storage.profileGet(userId))?.email ?? userId;
  };
  // Биометрическое подтверждение (этап 2б, решение владельца): ключ устройства защищён биометрией на устройстве;
  // сервер хранит только открытый ключ и проверяет подпись на одноразовом вызове.
  const BIO_ACTIONS = ['link-provider', 'remove-provider', 'set-backup-email', 'remove-backup-email', 'approve-device', 'enable-biometric', 'disable-biometric'];
  const bioMessage = (userId, deviceId, action, nonce) => `inone-stepup-v1|${userId}|${deviceId}|${action}|${nonce}`;
  const verifyBioSignature = (jwk, message, signatureB64) => {
    try {
      return createVerify('SHA256').update(message).verify({ key: createPublicKey({ key: jwk, format: 'jwk' }), dsaEncoding: 'der' }, Buffer.from(signatureB64, 'base64url'));
    } catch {
      return false;
    }
  };
  // Грант погашается один раз и только для своего действия и своего устройства.
  const consumeBioGrant = async (userId, action, grant, deviceId) => {
    if (typeof grant !== 'string' || grant === '') return false;
    const spent = await storage.consumeAuthToken('bio-grant', authTokenHash('bio-grant', grant), now());
    if (!spent || spent.userId !== userId) return false;
    const p = JSON.parse(spent.payload);
    return p.action === action && p.deviceId === deviceId;
  };
  // Одноразовые токены этапа 2 (nonce, билет регистрации, подтверждение входа): только ключевые хэши.
  const authTokenHash = (kind, token) => keyedHash(pinPepper, `auth:${kind}`, token);
  const newAuthToken = () => randomBytes(32).toString('base64url');
  // Сводка по аккаунту: уровень 0 — без подтверждённой почты, 1 — почта подтверждена, 2 — ещё и внешний аккаунт («Проверено»).
  const accountLevelInfo = async (userId) => {
    const profile = await storage.profileGet(userId);
    const links = await storage.providerLinksOf(userId);
    const backup = await storage.backupEmailGet(userId);
    const verificationLevel = profile?.emailVerified ? (links.length > 0 ? 2 : 1) : 0;
    return {
      userId,
      nickname: profile?.nickname ?? null,
      email: profile?.email ?? null,
      verificationLevel,
      providers: links.map((l) => l.provider),
      backupEmail: backup ? { email: backup.email, verified: backup.verified } : null,
      securityHints: backup ? [] : ['no_backup_email'],
    };
  };
  // Код подтверждения телефона: не чаще трёх раз в час. outcome: sent | limit (D5).
  const sendPhoneCode = async (userId, phone) => {
    const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
    const outcome = await storage.phoneUpdate(userId, (p0) => {
      const out = requestPhoneCode(p0, { nowMs: now(), phone, codeHash: phoneCodeHash(userId, code) });
      return { next: out.next, result: out.outcome };
    });
    if (outcome === 'sent') await smsSender.send(phone, `Код: ${code}. Введите его в InOne, чтобы подтвердить номер.`);
    return outcome;
  };
  const identityCodeHash = (userId, code) => keyedHash(pinPepper, `identity:${userId}`, code);
  // Токены и устройства лежат в хранилище; токен там хранится как ключевой хэш (C-08).
  // Через 48 часов после восстановления старые устройства отключаются, если их не отменили (D5, D8).
  // Окно хранится в базе: переживает перезапуск сервера.
  const finalizeRecoveryIfDue = async (userId) => {
    const current = await storage.recoveryGet(userId);
    if (current.windowKeyResetAt === null || now() < current.windowKeyResetAt) return;
    const dueSince = await storage.recoveryUpdate(userId, (r) => {
      const out = closeWindowIfDue(r, now());
      return { next: out.next, result: out.dueSince };
    });
    if (dueSince === null) return;
    for (const rec of await storage.devicesOfUser(userId)) {
      if (!rec.revoked && rec.createdAt < dueSince) await revokeDevice(rec);
    }
    await mail(userId, 'Старые устройства отключены', 'Прошло 48 часов после восстановления. Устройства, существовавшие до восстановления, отключены.');
  };
  const authed = async (req) => {
    const raw = (req.headers.authorization || '').replace('Bearer ', '');
    const dk = raw ? await storage.deviceKeyForToken(raw) : null;
    if (dk) await finalizeRecoveryIfDue((await storage.deviceRecord(dk))?.userId);
    const rec = dk ? await storage.deviceRecord(dk) : null;
    return rec && !rec.revoked ? rec : null;
  };
  const issueToken = (dk) => storage.issueToken(dk);
  // Окно восстановления: пока оно открыто, любое устройство аккаунта только читает (D5, D8).
  const inRecoveryWindow = async (req) => {
    const raw = (req.headers.authorization || '').replace('Bearer ', '');
    const dk = raw ? await storage.deviceKeyForToken(raw) : null;
    const d = dk ? await storage.deviceRecord(dk) : null;
    if (!d || d.revoked) return false;
    return windowOpen(await storage.recoveryGet(d.userId), now());
  };
  const activeCount = (userId) => storage.activeDeviceCount(userId);

  /**
   * Проверка PIN с блокировкой. Правила и защита от гонок — в хранилище: store.js (PostgreSQL)
   * или store-memory.js. Сервер подставляет время, лимит и функцию проверки хэша.
   */
  const verifyPin = (userId, pin) => storage.verifyPin(userId, pin, {
    now: now(),
    free: FREE_PIN_ATTEMPTS,
    lockDuration: lockDurationMs,
    check: (candidate, stored) => {
      pinChecks += 1;
      return checkPin(pinPepper, candidate, stored);
    },
  });

  const pinError = (res, r) => {
    if (r.reason === 'locked') {
      return send(res, 429, { error: 'too many wrong PIN attempts', retryAt: new Date(r.retryAt).toISOString() });
    }
    if (r.reason === 'no-pin') return send(res, 404, { error: 'no PIN set' });
    return send(res, 403, { error: 'wrong PIN' });
  };

  const server = http.createServer(async (req, res) => {
    const startedAt = Date.now();
    const pathOnly = req.url.split('?')[0];
    if (logger) res.on('finish', () => logger.info('request', { method: req.method, path: pathOnly, status: res.statusCode, ms: Date.now() - startedAt }));
    if (req.method === 'GET' && pathOnly === '/healthz') return send(res, 200, { status: 'ok' });
    if (req.method === 'GET' && pathOnly === '/readyz') {
      try {
        await storage.ping();
        return send(res, 200, { status: 'ready' });
      } catch {
        return send(res, 503, { status: 'not ready' });
      }
    }
    try {
      const chunks = [];
      let received = 0;
      for await (const c of req) {
        received += c.length;
        if (received > bodyLimit) {
          res.setHeader('Connection', 'close');
          return send(res, 413, { error: 'request body too large' });
        }
        chunks.push(c);
      }
      const raw = Buffer.concat(chunks).toString('utf8');
      // Тела сообщений (комнаты и личные) в журнал не пишутся: иначе удалённое осталось бы на сервере.
      const carriesMessage = /^\/(sendToDevice\/|rooms\/[^/]+\/(events|assets)|mls\/)/.test(req.url);
      // Журнал в памяти ограничен: без этого он рос бы с каждым запросом.
      if (wireLog.length >= wireLogLimit) wireLog.splice(0, wireLog.length - wireLogLimit + 1);
      wireLog.push(`${req.method} ${req.url} ${carriesMessage ? '[тело сообщения не записывается]' : raw.replace(/"(password|code|pin|currentPin|pollSecret|token)":"[^"]*"/g, '"$1":"***"')}`);

      let body = {};
      const isForm = String(req.headers['content-type'] || '').includes('application/x-www-form-urlencoded');
      try {
        // Форма из браузера (страница подтверждения восстановления) и JSON от приложения.
        body = !raw ? {} : isForm ? Object.fromEntries(new URLSearchParams(raw)) : JSON.parse(raw);
      } catch { return send(res, 400, { error: 'bad json' }); }
      const url = new URL(req.url, 'http://localhost');
      const p = url.pathname;
      // Окно восстановления: устройства только читают. Исключения: чтение чужих ключей и отмена (её право проверяет маршрут, D8).
      if (req.method !== 'GET' && !WINDOW_POST_OK.has(p) && (await inRecoveryWindow(req))) {
        return send(res, 403, { error: 'device is restricted during the recovery window' });
      }

      // ---------- аккаунт и вход ----------
      // ---------- вход и регистрация через Google и Apple (модель аккаунта, этап 2) ----------
      if (req.method === 'POST' && p === '/auth/nonce') {
        const perAddress = await checkRate('authNoncePerAddress', clientIp(req));
        if (!perAddress.allowed) return send(res, 429, { error: 'too many requests, try later' });
        const nonce = newAuthToken();
        await storage.issueAuthToken({ kind: 'nonce', tokenHash: authTokenHash('nonce', nonce), userId: null, payload: null, expiresAt: now() + 10 * 60_000 });
        return send(res, 200, { nonce });
      }

      if (req.method === 'POST' && p === '/auth/provider/verify') {
        const perAddress = await checkRate('providerAuthPerAddress', clientIp(req));
        if (!perAddress.allowed) return send(res, 429, { error: 'too many requests, try later' });
        const provider = body.provider;
        if (provider !== 'google' && provider !== 'apple') return send(res, 400, { error: 'provider must be google or apple' });
        if (!providers[provider]?.clientIds?.length) return send(res, 400, { error: 'provider is not enabled' });
        const nonce = typeof body.nonce === 'string' ? body.nonce : '';
        const spent = nonce === '' ? null : await storage.consumeAuthToken('nonce', authTokenHash('nonce', nonce), now());
        if (!spent) return send(res, 401, { error: 'nonce invalid or already used' });
        const checked = await verifyProviderToken(provider, body.idToken, nonce);
        if (!checked.ok) return send(res, checked.reason === 'unverified-email' ? 403 : 401, { error: `provider token rejected: ${checked.reason}` });
        const linked = await storage.providerLinkFind(provider, checked.identity.sub);
        if (linked) {
          const proof = newAuthToken();
          await storage.issueAuthToken({ kind: 'provider-proof', tokenHash: authTokenHash('provider-proof', proof), userId: linked.userId, payload: null, expiresAt: now() + 2 * 60_000 });
          return send(res, 200, { status: 'linked', userId: linked.userId, proof });
        }
        const ticket = newAuthToken();
        await storage.issueAuthToken({ kind: 'provider-ticket', tokenHash: authTokenHash('provider-ticket', ticket), userId: null, payload: JSON.stringify(checked.identity), expiresAt: now() + 30 * 60_000 });
        return send(res, 200, { status: 'new', ticket, email: checked.identity.email, relay: checked.identity.relay });
      }

      if (req.method === 'POST' && p === '/register/provider') {
        const reg = await checkRate('registrationsPerAddress', clientIp(req));
        if (!reg.allowed) return send(res, 429, { error: 'too many registrations from this address', retryAt: new Date(reg.retryAt).toISOString() });
        // Ник проверяем до погашения билета: опечатка в нике не заставляет входить у провайдера заново.
        const nickError = validateNickname(body.nickname);
        if (nickError) return send(res, 400, { error: nickError });
        if (await storage.searchNickname(body.nickname)) return send(res, 409, { error: 'nickname taken' });
        const ticket = typeof body.ticket === 'string' ? body.ticket : '';
        const spent = ticket === '' ? null : await storage.consumeAuthToken('provider-ticket', authTokenHash('provider-ticket', ticket), now());
        if (!spent) return send(res, 403, { error: 'registration ticket invalid or expired' });
        const identity = JSON.parse(spent.payload);
        const sameEmailError = 'email already registered: sign in with password and link the provider from settings';
        if (await storage.userIdByEmail(identity.email)) return send(res, 409, { error: sameEmailError });
        const userId = newUserId();
        const created = await storage.createVerifiedAccount({
          userId,
          // У аккаунта провайдера пароля нет: случайный непоказываемый хэш, вход только через провайдера.
          passwordHash: hashPassword(randomBytes(32).toString('hex')),
          email: identity.email,
          nickname: body.nickname,
          nowMs: now(),
          provider: { provider: identity.provider, sub: identity.sub },
        });
        if (created !== 'ok') {
          const error = created === 'nickname' ? 'nickname taken' : created === 'email' ? sameEmailError : created === 'link' ? 'this provider account is already linked' : 'account exists';
          return send(res, 409, { error });
        }
        const proof = newAuthToken();
        await storage.issueAuthToken({ kind: 'provider-proof', tokenHash: authTokenHash('provider-proof', proof), userId, payload: null, expiresAt: now() + 2 * 60_000 });
        return send(res, 200, { userId, nickname: body.nickname, verificationLevel: 2, proof });
      }

      // ---------- подтверждение действий над провайдерами: код с почты после привязки (этап 2) ----------
      // ---------- запасная почта: необязательна, подтверждается кодом (решение владельца) ----------
      if (req.method === 'POST' && p === '/account/backup-email/start') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const profile = await storage.profileGet(d.userId);
        if (!profile) return send(res, 400, { error: 'account has no verified email' });
        const email = normalizeEmail(body.email);
        if (!isEmail(email)) return send(res, 400, { error: 'email must be a valid address' });
        if (email === profile.email) return send(res, 400, { error: 'backup email must differ from the main email' });
        // Изменение запасной почты — действие с подтверждением: пароль или код с текущей почты.
        const confirmed = await verifyStepUp(d.userId, 'set-backup-email', body, d.deviceId);
        if (!confirmed.ok) return send(res, confirmed.status, { error: confirmed.error });
        const perAccount = await checkRate('backupEmailPerAccount', d.userId);
        if (!perAccount.allowed) return send(res, 429, { error: 'too many requests, try later' });
        const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
        await storage.emailCodeUpdate(backupKey(d.userId, email), (e) => ({
          next: requestEmailCode(e, { nowMs: now(), codeHash: backupCodeHash(d.userId, email, code) }),
          result: null,
        }));
        await mailTo(email, 'Подтверждение запасной почты InOne',
          `Код: ${code}. Этот адрес указан запасной почтой аккаунта InOne. Код действует 10 минут. Если это не вы, просто проигнорируйте письмо.`);
        return send(res, 202, { ok: true });
      }

      if (req.method === 'POST' && p === '/account/backup-email/confirm') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const email = normalizeEmail(body.email);
        if (!isEmail(email)) return send(res, 400, { error: 'email must be a valid address' });
        const code = typeof body.code === 'string' ? body.code : '';
        const outcome = await storage.emailCodeUpdate(backupKey(d.userId, email), (e) => {
          const out = checkEmailCode(e, {
            nowMs: now(),
            codeOk: !!e.codeHash && sameHex(backupCodeHash(d.userId, email, code), e.codeHash),
            tokenHash: null,
          });
          return { next: out.next, result: out.outcome };
        });
        if (outcome === 'none') return send(res, 404, { error: 'no code was requested for this address' });
        if (outcome === 'expired') return send(res, 410, { error: 'code expired, request a new one' });
        if (outcome === 'locked') return send(res, 403, { error: 'too many wrong codes, request a new one' });
        if (outcome !== 'ok') return send(res, 403, { error: 'wrong code' });
        const previous = await storage.backupEmailGet(d.userId);
        if ((await storage.backupEmailSave(d.userId, email, now())) === 'taken') {
          return send(res, 409, { error: 'this backup email is used by another account' });
        }
        const primary = (await storage.profileGet(d.userId)).email;
        await mailTo(primary, 'Запасная почта InOne изменена',
          `Запасная почта аккаунта ${previous ? 'изменена' : 'добавлена'}. Если это не вы, войдите в аккаунт и проверьте привязки и устройства.`);
        return send(res, 200, { backupEmail: { email, verified: true } });
      }

      if (req.method === 'POST' && p === '/account/backup-email/remove') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const confirmed = await verifyStepUp(d.userId, 'remove-backup-email', body, d.deviceId);
        if (!confirmed.ok) return send(res, confirmed.status, { error: confirmed.error });
        if (!(await storage.backupEmailRemove(d.userId))) return send(res, 404, { error: 'no backup email is set' });
        const primary = (await storage.profileGet(d.userId)).email;
        await mailTo(primary, 'Запасная почта InOne удалена',
          'Запасная почта удалена из аккаунта InOne. Если это не вы, войдите в аккаунт и проверьте привязки и устройства.');
        return send(res, 200, await accountLevelInfo(d.userId));
      }

      // ---------- биометрическое подтверждение: ключ устройства и одноразовые вызовы (этап 2б) ----------
      if (req.method === 'POST' && p === '/devices/signing-key') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const jwk = body.publicKey;
        const validKey = !!jwk && jwk.kty === 'EC' && jwk.crv === 'P-256' && typeof jwk.x === 'string' && typeof jwk.y === 'string' && jwk.d === undefined;
        if (!validKey) return send(res, 400, { error: 'publicKey must be an EC P-256 public key (JWK)' });
        try {
          createPublicKey({ key: jwk, format: 'jwk' });
        } catch {
          return send(res, 400, { error: 'publicKey is not a valid key' });
        }
        // Включение биометрии — действие с подтверждением: пароль или код с почты.
        const confirmed = await verifyStepUp(d.userId, 'enable-biometric', body, d.deviceId);
        if (!confirmed.ok) return send(res, confirmed.status, { error: confirmed.error });
        await storage.signingKeySet(key(d.userId, d.deviceId), { kty: 'EC', crv: 'P-256', x: jwk.x, y: jwk.y }, now());
        return send(res, 200, { ok: true });
      }

      if (req.method === 'POST' && p === '/devices/signing-key/remove') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const confirmed = await verifyStepUp(d.userId, 'disable-biometric', body, d.deviceId);
        if (!confirmed.ok) return send(res, confirmed.status, { error: confirmed.error });
        if (!(await storage.signingKeyDelete(key(d.userId, d.deviceId)))) return send(res, 404, { error: 'biometric is not enabled on this device' });
        return send(res, 200, { ok: true });
      }

      if (req.method === 'POST' && p === '/stepup/biometric/challenge') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        if (!BIO_ACTIONS.includes(body.action)) return send(res, 400, { error: 'unknown action' });
        if (!(await storage.signingKeyGet(key(d.userId, d.deviceId)))) return send(res, 400, { error: 'biometric is not enabled on this device' });
        const perAccount = await checkRate('bioChallengePerAccount', d.userId);
        if (!perAccount.allowed) return send(res, 429, { error: 'too many requests, try later' });
        const nonce = newAuthToken();
        const challengeId = newAuthToken();
        const expiresAt = now() + 2 * 60_000;
        await storage.issueAuthToken({ kind: 'bio-challenge', tokenHash: authTokenHash('bio-challenge', challengeId), userId: d.userId, payload: JSON.stringify({ deviceId: d.deviceId, action: body.action, nonce }), expiresAt });
        return send(res, 200, { challengeId, nonce, action: body.action, expiresAt: new Date(expiresAt).toISOString() });
      }

      if (req.method === 'POST' && p === '/stepup/biometric/confirm') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const challengeId = typeof body.challengeId === 'string' ? body.challengeId : '';
        const spent = challengeId === '' ? null : await storage.consumeAuthToken('bio-challenge', authTokenHash('bio-challenge', challengeId), now());
        if (!spent || spent.userId !== d.userId) return send(res, 403, { error: 'challenge invalid or expired' });
        const c = JSON.parse(spent.payload);
        // Подтвердить может только то устройство, которое запросило подтверждение.
        if (c.deviceId !== d.deviceId) return send(res, 403, { error: 'challenge belongs to another device' });
        const jwk = await storage.signingKeyGet(key(d.userId, c.deviceId));
        const signed = !!jwk && verifyBioSignature(jwk, bioMessage(d.userId, c.deviceId, c.action, c.nonce), String(body.signature ?? ''));
        if (!signed) return send(res, 403, { error: 'signature invalid' });
        const grant = newAuthToken();
        await storage.issueAuthToken({ kind: 'bio-grant', tokenHash: authTokenHash('bio-grant', grant), userId: d.userId, payload: JSON.stringify({ deviceId: c.deviceId, action: c.action }), expiresAt: now() + 60_000 });
        return send(res, 200, { grant, action: c.action, expiresInSeconds: 60 });
      }

      if (req.method === 'POST' && p === '/stepup/email/start') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const action = body.action;
        if (!STEPUP_ACTIONS.includes(action)) return send(res, 400, { error: 'unknown action' });
        // Пока пароль активен, подтверждение — пароль, код не выдаётся.
        if (await passwordSignInAllowed(d.userId)) return send(res, 400, { error: 'confirm with password' });
        if (!(await storage.profileGet(d.userId))) return send(res, 400, { error: 'account has no verified email' });
        const perAccount = await checkRate('stepupPerAccount', d.userId);
        if (!perAccount.allowed) return send(res, 429, { error: 'too many confirmation requests, try later' });
        const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
        await storage.emailCodeUpdate(stepupKey(d.userId), (e) => ({
          next: requestEmailCode(e, { nowMs: now(), codeHash: stepupCodeHash(d.userId, action, code) }),
          result: null,
        }));
        await mailTo(await confirmationEmail(d.userId), 'Подтверждение действия в InOne',
          `Код: ${code}. Действие: ${stepupActionText[action]}. Код действует 10 минут. Если это не вы, войдите в аккаунт и проверьте привязки и устройства.`);
        return send(res, 202, { ok: true });
      }

      if (req.method === 'POST' && p === '/stepup/email/confirm') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const action = body.action;
        if (!STEPUP_ACTIONS.includes(action)) return send(res, 400, { error: 'unknown action' });
        const code = typeof body.code === 'string' ? body.code : '';
        const stepupToken = newAuthToken();
        const outcome = await storage.emailCodeUpdate(stepupKey(d.userId), (e) => {
          const out = checkEmailCode(e, {
            nowMs: now(),
            codeOk: !!e.codeHash && sameHex(stepupCodeHash(d.userId, action, code), e.codeHash),
            tokenHash: stepupTokenHash(d.userId, action, stepupToken),
          });
          return { next: out.next, result: out.outcome };
        });
        if (outcome === 'ok') return send(res, 200, { stepupToken });
        if (outcome === 'none') return send(res, 404, { error: 'no code was requested' });
        if (outcome === 'expired') return send(res, 410, { error: 'code expired, request a new one' });
        if (outcome === 'locked') return send(res, 403, { error: 'too many wrong codes, request a new one' });
        return send(res, 403, { error: 'wrong code' });
      }
      if (req.method === 'POST' && p === '/account/providers') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        if (!(await storage.profileGet(d.userId))) return send(res, 400, { error: 'account has no verified email' });
        // Привязка внешнего аккаунта: пароль, пока он активен; после привязки — код с почты (решение владельца).
        const confirmed = await verifyStepUp(d.userId, 'link-provider', body, d.deviceId);
        if (!confirmed.ok) return send(res, confirmed.status, { error: confirmed.error });
        const provider = body.provider;
        if (provider !== 'google' && provider !== 'apple') return send(res, 400, { error: 'provider must be google or apple' });
        if (!providers[provider]?.clientIds?.length) return send(res, 400, { error: 'provider is not enabled' });
        const nonce = typeof body.nonce === 'string' ? body.nonce : '';
        const spent = nonce === '' ? null : await storage.consumeAuthToken('nonce', authTokenHash('nonce', nonce), now());
        if (!spent) return send(res, 401, { error: 'nonce invalid or already used' });
        const checked = await verifyProviderToken(provider, body.idToken, nonce);
        if (!checked.ok) return send(res, checked.reason === 'unverified-email' ? 403 : 401, { error: `provider token rejected: ${checked.reason}` });
        const linked = await storage.linkProvider({ userId: d.userId, provider, sub: checked.identity.sub, email: checked.identity.email, nowMs: now() });
        if (linked === 'taken') return send(res, 409, { error: 'this provider account is linked to another InOne account' });
        if (linked === 'provider-set') return send(res, 409, { error: 'this provider is already linked to your account' });
        // Пароль после привязки отключается полностью: хэш подменяется случайным, непоказываемым значением.
        await storage.setPasswordHash(d.userId, hashPassword(randomBytes(32).toString('hex')));
        return send(res, 200, await accountLevelInfo(d.userId));
      }

      if (req.method === 'POST' && p === '/account/providers/remove') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const confirmed = await verifyStepUp(d.userId, 'remove-provider', body, d.deviceId);
        if (!confirmed.ok) return send(res, confirmed.status, { error: confirmed.error });
        const provider = body.provider;
        if (provider !== 'google' && provider !== 'apple') return send(res, 400, { error: 'provider must be google or apple' });
        const links = await storage.providerLinksOf(d.userId);
        if (!links.some((l) => l.provider === provider)) return send(res, 404, { error: 'provider is not linked' });
        if (links.length <= 1) return send(res, 409, { error: 'cannot remove the last sign-in method' });
        await storage.unlinkProvider(d.userId, provider);
        return send(res, 200, await accountLevelInfo(d.userId));
      }

      // ---------- регистрация по почте (модель аккаунта, этап 1; режим verified — по умолчанию) ----------
      if (req.method === 'POST' && p === '/register/email' && registrationMode === 'verified') {
        // Ответ одинаковый, есть такая почта в системе или нет: по ответу не узнать, кто уже зарегистрирован.
        const email = normalizeEmail(body.email);
        if (!isEmail(email)) return send(res, 400, { error: 'email must be a valid address' });
        const perAddress = await checkRate('emailCodePerAddress', clientIp(req));
        const perEmail = await checkRate('emailCodePerEmail', email);
        if (!perAddress.allowed || !perEmail.allowed) return send(res, 429, { error: 'too many codes, try later' });
        if (!(await storage.userIdByEmail(email))) {
          const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
          await storage.emailCodeUpdate(email, (e) => ({
            next: requestEmailCode(e, { nowMs: now(), codeHash: emailCodeHash(email, code) }),
            result: null,
          }));
          await mailTo(email, 'Код подтверждения InOne',
            `Код: ${code}. Код действует 10 минут. Если вы не регистрировались в InOne, проигнорируйте письмо.`);
        }
        return send(res, 202, { ok: true });
      }

      if (req.method === 'POST' && p === '/register/email/confirm' && registrationMode === 'verified') {
        const email = normalizeEmail(body.email);
        if (!isEmail(email)) return send(res, 400, { error: 'email must be a valid address' });
        if (await storage.userIdByEmail(email)) return send(res, 409, { error: 'email already registered' });
        const code = typeof body.code === 'string' ? body.code : '';
        const token = randomBytes(24).toString('base64url');
        const outcome = await storage.emailCodeUpdate(email, (e) => {
          const out = checkEmailCode(e, {
            nowMs: now(),
            codeOk: !!e.codeHash && (sameHex(emailCodeHash(email, code), e.codeHash) || (!!devEmailCode && code === devEmailCode)),
            tokenHash: emailTokenHash(email, token),
          });
          return { next: out.next, result: out.outcome };
        });
        if (outcome === 'ok') return send(res, 200, { registrationToken: token });
        if (outcome === 'none') return send(res, 404, { error: 'no code was requested for this email' });
        if (outcome === 'expired') return send(res, 410, { error: 'code expired, request a new one' });
        if (outcome === 'locked') return send(res, 403, { error: 'too many wrong codes, request a new one' });
        return send(res, 403, { error: 'wrong code' });
      }

      if (req.method === 'POST' && p === '/register' && registrationMode === 'verified') {
        const email = normalizeEmail(body.email);
        const token = typeof body.registrationToken === 'string' ? body.registrationToken : '';
        // Лимит на регистрации с одного адреса: накрутка аккаунтов стоит денег (D5).
        const reg = await checkRate('registrationsPerAddress', clientIp(req));
        if (!reg.allowed) return send(res, 429, { error: 'too many registrations from this address', retryAt: new Date(reg.retryAt).toISOString() });
        if (!isEmail(email) || token === '') return send(res, 400, { error: 'email and registrationToken required' });
        if (typeof body.password !== 'string' || body.password.length < MIN_PASSWORD_LENGTH) {
          return send(res, 400, { error: `password required (min ${MIN_PASSWORD_LENGTH} chars)` });
        }
        const nickError = validateNickname(body.nickname);
        if (nickError) return send(res, 400, { error: nickError });
        if (await storage.userIdByEmail(email)) return send(res, 409, { error: 'email already registered' });
        if (await storage.searchNickname(body.nickname)) return send(res, 409, { error: 'nickname taken' });
                const hasPhoneV = body.phone !== undefined && body.phone !== null && body.phone !== '';
        if (requirePhone && !hasPhoneV) return send(res, 400, { error: 'phone required' });
        const phoneV = hasPhoneV ? normalizePhone(body.phone, { blockedCountries: phoneBlockedCountries, allowedCountries: phoneAllowedCountries }) : null;
        if (phoneV?.error) return send(res, 400, { error: phoneV.error });
        if (phoneV && (await storage.phoneOwner(phoneV.value.e164))) return send(res, 409, { error: 'phone already used by another account' });
// Токен одноразовый: гасится до создания аккаунта, чтобы им нельзя было воспользоваться дважды.
        const used = await storage.emailCodeUpdate(email, (e) => {
          const out = useEmailToken(e, { nowMs: now(), tokenOk: !!e.tokenHash && sameHex(emailTokenHash(email, token), e.tokenHash) });
          return { next: out.next, result: out.outcome };
        });
        if (used === 'expired') return send(res, 410, { error: 'registration token expired' });
        if (used !== 'ok') return send(res, 403, { error: 'registration token invalid' });
        const userId = newUserId();
        const created = await storage.createVerifiedAccount({
          userId, passwordHash: hashPassword(body.password), email, nickname: body.nickname, nowMs: now(),
        });
        if (created !== 'ok') {
          const error = created === 'nickname' ? 'nickname taken' : created === 'email' ? 'email already registered' : 'account exists';
          return send(res, 409, { error });
        }
        if (phoneV) {
      const e164 = phoneV.value.e164;
      try {
        if (smsEnabled) await sendPhoneCode(userId, e164);
        else await storage.phoneUpdate(userId, () => ({ next: { phone: e164, verified: false, codeHash: null, codeAttempts: 0, codeExpiresAt: 0, sends: [] }, result: 'saved' }));
      } catch (e) {
        if (e.code === '23505') return send(res, 409, { error: 'phone already used by another account' });
        throw e;
      }
    }
    return send(res, 200, { userId, nickname: body.nickname, verificationLevel: 1 });
      }

      // ---------- поиск по нику и свой профиль (модель аккаунта, этап 1) ----------
      if (req.method === 'GET' && p === '/users/search') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const perAccount = await checkRate('searchPerAccount', d.userId);
        const perAddress = await checkRate('searchPerAddress', clientIp(req));
        if (!perAccount.allowed || !perAddress.allowed) return send(res, 429, { error: 'too many searches, try later' });
        const nickname = new URL(req.url, 'http://localhost').searchParams.get('nickname') ?? '';
        if (validateNickname(nickname)) return send(res, 400, { error: 'nickname has an invalid format' });
        const found = await storage.searchNickname(nickname);
        if (!found) return send(res, 404, { error: 'not found' });
        // Почта и номер в ответе не отдаются: найти пользователя можно только по нику.
        const info = await accountLevelInfo(found.userId);
        return send(res, 200, { userId: found.userId, nickname: found.nickname, verificationLevel: info.verificationLevel });
      }

      if (req.method === 'GET' && p === '/profile') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const info = await accountLevelInfo(d.userId);
        // Подсказка (решение владельца): аккаунт связан с Google или Apple, а на этом устройстве биометрия ещё не включена.
        if (info.providers.length > 0 && !(await storage.signingKeyGet(key(d.userId, d.deviceId)))) {
          info.securityHints = [...info.securityHints, 'offer_biometric'];
        }
        return send(res, 200, info);
      }

      if (req.method === 'POST' && p === '/register' && registrationMode === 'open') {
        const { userId, password, phone } = body;
        // Лимит на регистрации с одного адреса: накрутка аккаунтов и SMS стоит денег (D5).
        const reg = await checkRate('registrationsPerAddress', clientIp(req));
        if (!reg.allowed) return send(res, 429, { error: 'too many registrations from this address', retryAt: new Date(reg.retryAt).toISOString() });
        if (!userId || typeof password !== 'string' || password.length < MIN_PASSWORD_LENGTH) {
          return send(res, 400, { error: 'userId and password (min 8 chars) required' });
        }
        const hasPhone = phone !== undefined && phone !== null;
        if (requirePhone && !hasPhone) return send(res, 400, { error: 'phone required' });
        const phoneNorm = hasPhone ? normalizePhone(phone, { blockedCountries: phoneBlockedCountries, allowedCountries: phoneAllowedCountries }) : null;
        if (phoneNorm?.error) return send(res, 400, { error: phoneNorm.error });
        if (phoneNorm) {
          // На один номер SMS приходят не чаще заданного за сутки, с любого адреса и с любого аккаунта.
          const perPhone = await checkRate('phoneRegistrationPerPhone', phoneNorm.value.e164);
          // Когда SMS подключены, регистрация с номером тратит тот же суточный лимит SMS на номер.
          if (smsEnabled) {
            const smsCount = await checkRate('smsPerPhone', phoneNorm.value.e164);
            if (!smsCount.allowed) return send(res, 429, { error: 'too many codes for this phone, try tomorrow', retryAt: new Date(smsCount.retryAt).toISOString() });
          }
          if (!perPhone.allowed) return send(res, 429, { error: 'too many codes for this phone, try tomorrow', retryAt: new Date(perPhone.retryAt).toISOString() });
        }
        if (phoneNorm && (await storage.phoneOwner(phoneNorm.value.e164))) return send(res, 409, { error: 'phone already used by another account' });
        if (!(await storage.addAccount(userId, hashPassword(password)))) return send(res, 409, { error: 'account exists' });
        // Номер подтверждается кодом из SMS: до подтверждения он не даёт права на восстановление (D5).
        if (phoneNorm) {
          const e164 = phoneNorm.value.e164;
          // SMS пока не подключён: номер закрепляется за аккаунтом в ожидании подтверждения, код не отправляется.
          try {
            if (smsEnabled) await sendPhoneCode(userId, e164);
            else await storage.phoneUpdate(userId, () => ({ next: { phone: e164, verified: false, codeHash: null, codeAttempts: 0, codeExpiresAt: 0, sends: [] }, result: 'saved' }));
          } catch (e) {
            if (e.code === '23505') return send(res, 409, { error: 'phone already used by another account' });
            throw e;
          }
        }
        return send(res, 200, { ok: true });
      }

      if (req.method === 'POST' && p === '/account/phone') {
      if (!smsEnabled) return send(res, 503, { error: 'SMS verification is not available yet' });
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        // Смена номера требует пароль: украденное устройство само по себе номер не меняет (D5).
        const stored = await storage.accountHash(d.userId);
        if (typeof body.password !== 'string' || !(await passwordSignInAllowed(d.userId)) || !checkPassword(body.password, stored)) return send(res, 403, { error: 'password required to change the phone' });
        const phoneNorm = normalizePhone(body.phone, { blockedCountries: phoneBlockedCountries, allowedCountries: phoneAllowedCountries });
        if (phoneNorm.error) return send(res, 400, { error: phoneNorm.error });
        const holder = await storage.phoneOwner(phoneNorm.value.e164);
        if (holder && holder !== d.userId) return send(res, 409, { error: 'phone already used by another account' });
        const perPhone = await checkRate('smsPerPhone', phoneNorm.value.e164);
        if (!perPhone.allowed) return send(res, 429, { error: 'too many codes for this phone, try tomorrow', retryAt: new Date(perPhone.retryAt).toISOString() });
        let outcome;
        try {
          outcome = await sendPhoneCode(d.userId, phoneNorm.value.e164);
        } catch (e) {
          if (e.code === '23505') return send(res, 409, { error: 'phone already used by another account' });
          throw e;
        }
        if (outcome === 'limit') return send(res, 429, { error: 'too many codes, try later' });
        return send(res, 202, { ok: true });
      }

      if (req.method === 'POST' && p === '/account/phone/confirm') {
      if (!smsEnabled) return send(res, 503, { error: 'SMS verification is not available yet' });
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const code = body.code;
        const matches = (p0) => typeof code === 'string' && !!p0.codeHash && sameHex(phoneCodeHash(d.userId, code), p0.codeHash);
        const current = await storage.phoneGet(d.userId);
        // Один подтверждённый номер — один аккаунт: номер, уже подтверждённый другим аккаунтом, не принимается.
        if (checkPhoneCode(current, { nowMs: now(), codeOk: matches(current) }).outcome === 'ok') {
          const owner = await storage.verifiedPhoneOwner(current.phone);
          if (owner !== null && owner !== d.userId) return send(res, 409, { error: 'phone already used by another account' });
        }
        let outcome;
        try {
          outcome = await storage.phoneUpdate(d.userId, (p0) => {
            const out = checkPhoneCode(p0, { nowMs: now(), codeOk: matches(p0) });
            return { next: out.next, result: out.outcome };
          });
        } catch (e) {
          if (e.code === '23505') return send(res, 409, { error: 'phone already used by another account' });
          throw e;
        }
        if (outcome === 'ok') return send(res, 200, { ok: true });
        if (outcome === 'none') return send(res, 404, { error: 'no code requested' });
        if (outcome === 'expired') return send(res, 410, { error: 'code expired' });
        return send(res, 403, { error: 'wrong code' });
      }

      // ---------- отмена отложенного входа по коду из письма (аккаунт без активных устройств) ----------
      if (req.method === 'POST' && p === '/admission/cancel') {
        const email = normalizeEmail(body.email);
        const perEmail = await checkRate('deviceWaitCancelPerEmail', email);
        if (!perEmail.allowed) return send(res, 429, { error: 'too many attempts, try later' });
        const userId = await storage.userIdByEmail(email);
        const code = typeof body.code === 'string' ? body.code : '';
        const waits = userId ? await storage.deviceWaitsOf(userId) : [];
        const match = waits.find((w) => sameHex(deviceWaitCodeHash(userId, w.deviceId, code), w.cancelHash));
        if (!match) return send(res, 403, { error: 'wrong code' });
        await storage.deviceWaitDelete(userId, match.deviceId);
        return send(res, 200, { ok: true, deviceId: match.deviceId });
      }
      if (req.method === 'POST' && p === '/login') {
        // Вход по почте (подтверждённый аккаунт) или по внутреннему идентификатору (режим open и старые аккаунты).
        const loginEmail = normalizeEmail(body.email);
        const userId = body.userId ?? ((loginEmail && (await storage.userIdByEmail(loginEmail))) || loginEmail);
        const { password, deviceId, label, platform, identityCode, proof: providerProof } = body;
        const stored = await storage.accountHash(userId);
        // Вход через Google или Apple: одноразовое подтверждение провайдера вместо пароля (этап 2).
        let providerOk = null;
        if (typeof providerProof === 'string' && providerProof !== '') {
          const spent = await storage.consumeAuthToken('provider-proof', authTokenHash('provider-proof', providerProof), now());
          providerOk = !!spent && spent.userId === userId && !!stored;
        }
        // Одинаковый ответ и одинаковое время для неизвестного логина и для неверного пароля (C-04):
        // проверка идёт через scrypt всегда, для неизвестного логина — против фиктивного хэша.
        const candidate = typeof password === 'string' ? password : '';
        const source = clientIp(req);
        // Защита входа (D7): задержки по паре «адрес и логин», ограничение адреса, уведомление владельцу.
        // После привязки Google или Apple пароль не принимается (решение владельца).
        const linkedCount = (await storage.providerLinksOf(userId)).length;
        const verdict = await storage.throttledLogin({
          pairKey: `pair|${source}|${userId}`,
          sourceKey: `src|${source}`,
          loginKey: `login|${userId}`,
          now: now(),
          verify: () => (providerOk !== null ? providerOk : checkPassword(candidate, stored ?? DUMMY_PASSWORD_HASH) && !!stored && typeof password === 'string' && linkedCount === 0),
          policy: LOGIN_POLICY,
          notify: !!stored,
        });
        if (verdict.status === 'throttled') {
          return send(res, 429, { error: 'too many attempts', retryAt: new Date(verdict.retryAt).toISOString() });
        }
        if (verdict.status === 'wrong') {
          // Владельцу — уведомление после нескольких неудач, без блокировки входа.
          if (verdict.notify) await alertDevices(userId, { kind: 'login_failures' });
          return send(res, 401, { error: 'wrong credentials' });
        }
        if (!deviceId) return send(res, 400, { error: 'deviceId required' });
        const dk = key(userId, deviceId);
        const existing = await storage.deviceRecord(dk);
        if (existing?.revoked) return send(res, 403, { error: 'device revoked; log in with a new device id' });

        // Новое устройство в аккаунте с уже активными устройствами: нужен код с одного из них.
        // Окно восстановления и первый вход после него (D1, D5, D8).
        await finalizeRecoveryIfDue(userId);
        const rec = await storage.recoveryGet(userId);
        let identityPassed = false;
        // Аккаунт без подтверждённого телефона: в окне 48 часов новое устройство не добавляется, даже с кодом с почты (решение владельца).
        if (!existing && windowOpen(rec, now()) && !(await storage.phoneGet(userId)).verified) {
          return send(res, 403, { error: 'new devices can be added after the recovery window closes' });
        }
        if (!existing && rec.identityCheck) {
          if (identityCode === undefined) {
            const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
            await storage.recoveryUpdate(userId, (r) => ({ next: issueIdentity(r, { codeHash: identityCodeHash(userId, code) }), result: null }));
            await mail(userId, 'Подтверждение входа после восстановления',
              `Код: ${code}. Введите его, чтобы войти с нового устройства. Если это не вы — отмените восстановление с устройства, которое существовало до запроса.`);
            return send(res, 202, { status: 'identity_check_required' });
          }
          const outcome = await storage.recoveryUpdate(userId, (r) => {
            const out = checkIdentity(r, {
              codeOk: typeof identityCode === 'string' && !!r.identityCodeHash && sameHex(identityCodeHash(userId, identityCode), r.identityCodeHash),
            });
            return { next: out.next, result: out.outcome };
          });
          if (outcome !== 'ok') return send(res, 403, { error: 'wrong identity code' });
          identityPassed = true;
        }
        // В окне восстановления новые устройства не добавляются, кроме первого входа по коду (D8).
        if (!existing && !identityPassed && windowOpen(rec, now())) {
          return send(res, 403, { error: 'new devices can be added after the recovery window closes' });
        }
        // Все устройства аккаунта отключены, а вход с нового устройства — только по почте: ждём 48 часов (решение владельца).
        // Аккаунт с привязкой Google или Apple и аккаунт без устройств в истории пускаются сразу.
        if (!existing && !identityPassed && (await storage.devicesOfUser(userId)).length > 0
            && (await activeCount(userId)) === 0 && (await storage.providerLinksOf(userId)).length === 0) {
          const waiting = await storage.deviceWaitGet(userId, deviceId);
          if (!waiting) {
            const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
            const activateAt = now() + DEVICE_WAIT_MS;
            await storage.deviceWaitCreate({ userId, deviceId, label: label ?? null, platform: platform ?? null,
              activateAt, cancelHash: deviceWaitCodeHash(userId, deviceId, code), createdAt: now() });
            await mail(userId, 'Вход с нового устройства: ожидание 48 часов',
              `Вход с нового устройства откроется ${new Date(activateAt).toISOString()}. Если это не вы, отмените вход кодом ${code} (POST /admission/cancel).`);
            return send(res, 202, { status: 'waiting_period', activateAt: new Date(activateAt).toISOString() });
          }
          if (waiting.activateAt > now()) {
            return send(res, 202, { status: 'waiting_period', activateAt: new Date(waiting.activateAt).toISOString() });
          }
        }
        if (!existing && !identityPassed && (await activeCount(userId)) > 0) {
          const id = randomUUID();
          const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
          const pollSecret = randomBytes(32).toString('base64url');
          const created = await storage.createApproval({
            id, userId, deviceId, label: label ?? null, platform: platform ?? null,
            codeHash: sha(`${id}:${code}`), pollHash: sha(pollSecret),
            status: 'pending', attempts: 0, createdAt: now(), expiresAt: now() + APPROVAL_TTL_MS,
          }, { max: MAX_PENDING_APPROVALS, now: now() });
          if (!created) return send(res, 429, { error: 'too many pending sign-in requests' });
          await alertDevices(userId, { kind: 'device_approval_requested', deviceLabel: label ?? null, platform: platform ?? null });
          // Код показывается на новом устройстве. Владелец вводит его на старом.
          return send(res, 202, { status: 'approval_required', approvalId: id, code, pollSecret });
        }

        if (!existing) {
          await storage.addDevice(userId, deviceId, label ?? null, now());
        }
        await storage.deviceWaitDelete(userId, deviceId);
        return send(res, 200, { token: await issueToken(dk), deviceId });
      }

      // ---------- подтверждение входа с нового устройства ----------
      if (req.method === 'GET' && p === '/approvals') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const list = (await storage.listPendingApprovals(d.userId, now())).map((a) => ({
          id: a.id, label: a.label, platform: a.platform,
          createdAt: new Date(a.createdAt).toISOString(), expiresAt: new Date(a.expiresAt).toISOString(),
        }));
        return send(res, 200, { approvals: list });
      }

      const ap = p.match(/^\/approvals\/([^/]+)\/(approve|deny|claim)$/);
      if (ap && req.method === 'POST') {
        const [, id, action] = ap;

        if (action === 'claim') {
          // Новое устройство забирает результат по своему секрету. Один раз.
          const r = await storage.readApprovalForClaim(id, sha(body.pollSecret ?? ''), now());
          if (r.status === 'unknown') return send(res, 404, { error: 'unknown request' });
          if (r.status === 'denied') return send(res, 200, { status: 'denied' });
          if (r.status === 'expired') return send(res, 200, { status: 'expired' });
          if (r.status === 'pending') return send(res, 200, { status: 'pending' });
          const dk = key(r.userId, r.deviceId);
          const existing = await storage.deviceRecord(dk);
          if (existing?.revoked) return send(res, 403, { error: 'device revoked' });
          // Результат выдаётся один раз: побеждает только тот запрос, который первым переведёт запись в consumed.
          if (!(await storage.consumeApproval(id))) return send(res, 404, { error: 'unknown request' });
          if (!existing) {
            await storage.addDevice(r.userId, r.deviceId, r.label, now());
          }
          return send(res, 200, { status: 'approved', token: await issueToken(dk), deviceId: r.deviceId });
        }

        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        // Устройство с биометрическим ключом одобряет новое устройство только с подтверждением биометрией (этап 2б).
        if (action === 'approve' && (await storage.signingKeyGet(key(d.userId, d.deviceId)))) {
          if (!(await consumeBioGrant(d.userId, 'approve-device', body.bioGrant, d.deviceId))) {
            return send(res, 403, { error: 'biometric confirmation required to approve a device' });
          }
        }
        const decision = await storage.decideApproval(id, d.userId, action, {
          now: now(),
          codeMatches: (codeHash) => sameHex(sha(`${id}:${body.code ?? ''}`), codeHash),
          max: MAX_APPROVAL_CODE_ATTEMPTS,
        });
        if (decision.status === 'unknown') return send(res, 404, { error: 'unknown request' });
        if (action === 'deny') {
          await alertDevices(d.userId, { kind: 'device_denied', deviceLabel: decision.label });
          return send(res, 200, { ok: true });
        }
        if (decision.status === 'wrong') {
          if (decision.denied) await alertDevices(d.userId, { kind: 'device_denied', deviceLabel: decision.label });
          return send(res, 403, { error: 'wrong code' });
        }
        await alertDevices(d.userId, { kind: 'device_approved', deviceLabel: decision.label });
        return send(res, 200, { ok: true });
      }

      // ---------- PIN ----------
      if (req.method === 'POST' && p === '/pin/set') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const pin = String(body.pin ?? '');
        const weak = weakPinReason(pin);
        if (weak) return send(res, 400, { error: weak });
        if (await storage.hasPin(d.userId)) {
          const r = await verifyPin(d.userId, String(body.currentPin ?? ''));
          if (!r.ok) return pinError(res, r);
        }
        await storage.setPin(d.userId, hashPin(pinPepper, pin));
        await alertDevices(d.userId, { kind: 'pin_changed' });
        return send(res, 200, { ok: true });
      }

      if (req.method === 'POST' && p === '/pin/remove') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const r = await verifyPin(d.userId, String(body.currentPin ?? ''));
        if (!r.ok) return pinError(res, r);
        await storage.removePin(d.userId);
        await alertDevices(d.userId, { kind: 'pin_removed' });
        return send(res, 200, { ok: true });
      }

      // ---------- устройства ----------
      if (req.method === 'GET' && p === '/devices') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const list = (await storage.devicesOfUser(d.userId)).filter((x) => !x.revoked).map((x) => ({ deviceId: x.deviceId, label: x.label }));
        return send(res, 200, { devices: list });
      }

      const dev = p.match(/^\/devices\/([^/]+)$/);
      if (dev && req.method === 'DELETE') {
        const me = await authed(req);
        if (!me) return send(res, 401, { error: 'unauthorized' });
        const target = await storage.deviceRecord(key(me.userId, decodeURIComponent(dev[1])));
        if (!target || target.revoked) return send(res, 404, { error: 'unknown device' });
        await revokeDevice(target);
        await markChanged(me.userId);
        return send(res, 200, { ok: true });
      }

      // ---------- ключи шифрования ----------
      if (req.method === 'POST' && p === '/keys/upload') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const k = key(d.userId, d.deviceId);
        if (body.device_keys) {
          const dk = body.device_keys;
          // Нельзя загрузить ключи от имени другого пользователя или устройства.
          if (dk.user_id !== d.userId || dk.device_id !== d.deviceId) {
            return send(res, 403, { error: 'device keys belong to another device' });
          }
          await storage.putDeviceKeys(k, dk);
        }
        await storage.addOneTimeKeys(k, body.one_time_keys || {});
        const remaining = await storage.countOneTimeKeys(k, 'signed_curve25519:');
        await markChanged(d.userId);
        return send(res, 200, { one_time_key_counts: { signed_curve25519: remaining } });
      }

      if (req.method === 'POST' && p === '/keys/query') {
        if (!(await authed(req))) return send(res, 401, { error: 'unauthorized' });
        const out = {};
        for (const user of Object.keys(body.device_keys || {})) out[user] = await storage.queryDeviceKeys(user);
        return send(res, 200, { device_keys: out, failures: {} });
      }

      if (req.method === 'POST' && p === '/keys/claim') {
        if (!(await authed(req))) return send(res, 401, { error: 'unauthorized' });
        const out = {};
        for (const [user, devs] of Object.entries(body.one_time_keys || {})) {
          out[user] = {};
          for (const dev2 of Object.keys(devs)) {
            const claimed = await storage.claimOneTimeKey(key(user, dev2)); // одноразовый ключ выдаётся один раз
            if (claimed) out[user][dev2] = claimed;
          }
        }
        return send(res, 200, { one_time_keys: out, failures: {} });
      }

      if (req.method === 'PUT' && p.startsWith('/sendToDevice/')) {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const [, , rawType = '', rawTxn = ''] = p.split('/');
        const type = decodeURIComponent(rawType);
        const txn = decodeURIComponent(rawTxn);
        // Повтор с тем же номером (клиент не получил ответ) не создаёт второй копии (C-05).
        if (txn && !(await storage.recordSend(key(d.userId, d.deviceId), type, txn, now(), SEND_DEDUP_MS))) {
          return send(res, 200, {});
        }
        for (const [user, devs] of Object.entries(body.messages || {})) {
          for (const [dev2, content] of Object.entries(devs)) {
            const k2 = key(user, dev2);
            const target = await storage.deviceRecord(k2);
            if (!target || target.revoked) continue; // отключённым устройствам не доставляем
            // Событие получает номер и срок хранения: без подтверждения оно удаляется через 30 дней (C-05).
            await storage.enqueue(k2, 'to_device', { type, sender: d.userId, content }, null, now() + TO_DEVICE_TTL_MS);
          }
        }
        return send(res, 200, {});
      }

      if (req.method === 'GET' && p === '/sync') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const number = (name) => {
          const raw = url.searchParams.get(name) ?? '0';
          return /^\d{1,15}$/.test(raw) ? Number(raw) : null;
        };
        const acked = number('since');               // подтверждённые события доставки (C-05)
        const signalAcked = number('signal_since');  // подтверждённые сигналы (C-20)
        if (acked === null || signalAcked === null) {
          return send(res, 400, { error: 'since and signal_since must be non-negative integers' });
        }
        const k = key(d.userId, d.deviceId);
        // Каждый поток подтверждается своим номером. Подтверждённое и истёкшее удаляет хранилище; остальное отдаётся снова.
        const queued = await storage.drainQueue(k, acked, signalAcked, now());
        const events = queued.map((e) => ({ id: e.id, stream: e.stream, dedupeKey: e.dedupeKey, ...e.body }));
        const toDevice = events.filter((e) => e.stream === 'to_device');
        const signals = events.filter((e) => e.stream !== 'to_device');
        const last = (list, fallback) => String(list.length ? list.at(-1).id : fallback);
        const wireSignal = (e) => {
          if (e.stream === 'security') return { id: e.id, stream: e.stream, body: e.body };
          if (e.stream === 'device_list') return { id: e.id, stream: e.stream, userId: e.userId };
          return { id: e.id, stream: e.stream, roomId: e.roomId };
        };
        const uniq = (list) => [...new Set(list)];
        const count = await storage.countOneTimeKeys(k, 'signed_curve25519:');
        return send(res, 200, {
          to_device: {
            events: toDevice.map(({ id, type, sender, content }) => ({ id, type, sender, content })),
            next_batch: last(toDevice, acked),
          },
          signals: { items: signals.map(wireSignal), next_batch: last(signals, signalAcked) },
          device_one_time_keys_count: { signed_curve25519: count },
          // Прежние поля, оставлены для совместимости с версией 0.5.x. Новому клиенту они не нужны.
          security: signals.filter((e) => e.stream === 'security').map((e) => e.body),
          device_lists: { changed: uniq(signals.filter((e) => e.stream === 'device_list').map((e) => e.userId)), left: [] },
          rooms: { changed: uniq(signals.filter((e) => e.stream === 'room').map((e) => e.roomId)) },
        });
      }

      // ---------- беседы и участники ----------
      if (req.method === 'POST' && p === '/rooms') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = String(body.roomId ?? '');
        if (!roomId) return send(res, 400, { error: 'roomId required' });
        if (await storage.getRoom(roomId)) return send(res, 409, { error: 'room exists' });
        const kindParam = body.kind ?? 'group';
        if (!['group', 'channel'].includes(kindParam)) return send(res, 400, { error: 'kind must be group or channel' });
        let roomName = null;
        if (body.name !== undefined && body.name !== null) {
          const checkedName = normalizeRoomName(body.name);
          if (checkedName.error) return send(res, 400, { error: checkedName.error });
          roomName = checkedName.value;
        }
        if (kindParam === 'channel') {
          if (!roomName) return send(res, 400, { error: 'a channel needs a name' });
          if (await storage.channelNameTaken(roomName, null)) return send(res, 409, { error: 'channel name is taken' });
        }

        const memberSet = new Set([d.userId, ...(body.members || [])]);
        for (const m of memberSet) {
          if (!(await storage.hasAccount(m))) return send(res, 404, { error: `unknown user ${m}` });
        }
        // Для каждого участника запоминается номер события, с которого он видит беседу (C-07).
        let created;
        try {
          created = await storage.createRoom(roomId, d.userId, [...memberSet], { kind: kindParam, name: roomName });
        } catch (e) {
          if (e.code === '23505') return send(res, 409, { error: 'channel name is taken' });
          throw e;
        }
        if (!created) return send(res, 409, { error: 'room exists' });
        await markRoomChanged(roomId, [...memberSet]);
        return send(res, 200, { roomId });
      }

      // Название комнаты: владелец меняет его. У канала название уникально, у группы может повторяться.
      const nameRoute = p.match(/^\/rooms\/([^/]+)\/name$/);
      if (nameRoute && req.method === 'PUT') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(nameRoute[1]);
        const r = await storage.getRoom(roomId);
        if (!r) return send(res, 404, { error: 'room not found' });
        if (d.userId !== r.owner) return send(res, 403, { error: 'only the owner can rename the room' });
        const checkedName = normalizeRoomName(body.name);
        if (checkedName.error) return send(res, 400, { error: checkedName.error });
        if ((await storage.roomKind(roomId)) === 'channel' && (await storage.channelNameTaken(checkedName.value, roomId))) {
          return send(res, 409, { error: 'channel name is taken' });
        }
        try {
          await storage.setRoomName(roomId, checkedName.value);
        } catch (e) {
          if (e.code === '23505') return send(res, 409, { error: 'channel name is taken' });
          throw e;
        }
        await markRoomChanged(roomId, r.members);
        return send(res, 200, { name: checkedName.value });
      }

      const memberRoute = p.match(/^\/rooms\/([^/]+)\/members$/);
      if (memberRoute && req.method === 'GET') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const r = await storage.getRoom(decodeURIComponent(memberRoute[1]));
        if (!r || !r.members.includes(d.userId)) return send(res, 403, { error: 'not a member' });
        const capabilities = Object.fromEntries(r.members.map((m) => [m, [...effectiveCapabilities(r, m)].sort()]));
        const readUpTo = Object.fromEntries(Object.entries(r.readUpTo).map(([u, s]) => [u, s > 0 ? `$${s}` : null]));
        // Файлы, которые ждут замены под текущий вид группы: видны только участникам в этом списке.
        const pending = [];
        for (const key of ['avatarAssetId', 'coverAssetId', 'backgroundAssetId']) {
          if (!r[key]) continue;
          const asset = await storage.getRoomAsset(decodeURIComponent(memberRoute[1]), r[key]);
          if (asset && !assetMatchesVisibility(asset, r)) pending.push(r[key]);
        }
        const appearance = { description: r.description, backgroundColor: r.backgroundColor, avatarAssetId: r.avatarAssetId, coverAssetId: r.coverAssetId, backgroundAssetId: r.backgroundAssetId, pending };
        return send(res, 200, { owner: r.owner, admins: r.admins, members: r.members, capabilities, name: r.name, visibility: r.visibility, join_policy: r.joinPolicy, read_upto: readUpTo, appearance });
      }
      if (memberRoute && req.method === 'POST') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(memberRoute[1]);
        const r = await storage.getRoom(roomId);
        if (!r || !hasCapability(r, d.userId, 'invite_members')) {
          return send(res, 403, { error: 'missing capability: invite_members' });
        }
        const userId = String(body.userId ?? '');
        if (!(await storage.hasAccount(userId))) return send(res, 404, { error: 'unknown user' });
        // Новый участник видит только то, что придёт после его добавления (C-07).
        await storage.addRoomMember(roomId, userId);
        await markRoomChanged(roomId, (await storage.getRoom(roomId)).members);
        return send(res, 200, { ok: true });
      }

      const roleRoute = p.match(/^\/rooms\/([^/]+)\/roles$/);
      if (roleRoute && req.method === 'POST') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(roleRoute[1]);
        const r = await storage.getRoom(roomId);
        // Роли назначает только владелец.
        if (!r || r.owner !== d.userId) return send(res, 403, { error: 'only the owner can change roles' });
        const target = String(body.userId ?? '');
        if (!r.members.includes(target)) return send(res, 404, { error: 'not a member' });
        if (target === r.owner) return send(res, 409, { error: 'owner role cannot be changed' });
        if (body.role !== 'admin' && body.role !== 'member') return send(res, 400, { error: 'role must be admin or member' });
        await storage.setRoomAdmin(roomId, target, body.role === 'admin');
        return send(res, 200, { ok: true });
      }

      const capsRoute = p.match(/^\/rooms\/([^/]+)\/capabilities$/);
      if (capsRoute && req.method === 'POST') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(capsRoute[1]);
        const r = await storage.getRoom(roomId);
        // Права выдаёт и отбирает только владелец.
        if (!r || r.owner !== d.userId) return send(res, 403, { error: 'only the owner can change capabilities' });
        const target = String(body.userId ?? '');
        if (!r.members.includes(target)) return send(res, 404, { error: 'not a member' });
        if (target === r.owner) return send(res, 409, { error: 'owner has all capabilities' });
        const list = normalizeCapabilities(body.capabilities);
        if (!list) return send(res, 400, { error: 'capabilities must be a list of known capability names' });
        await storage.setRoomCapabilities(roomId, target, list);
        return send(res, 200, { ok: true, capabilities: list });
      }

      const memberOne = p.match(/^\/rooms\/([^/]+)\/members\/([^/]+)$/);
      // Передача владения: только текущий владелец; новым владельцем становится участник группы.
      const ownerRoute = p.match(/^\/rooms\/([^/]+)\/owner$/);
      if (ownerRoute && req.method === 'POST') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(ownerRoute[1]);
        const r = await storage.getRoom(roomId);
        if (!r) return send(res, 404, { error: 'group not found' });
        if (d.userId !== r.owner) return send(res, 403, { error: 'only the owner can transfer ownership' });
        const target = typeof body?.userId === 'string' ? body.userId : '';
        if (!target || target === r.owner) return send(res, 400, { error: 'userId of another member is required' });
        if (!r.members.includes(target)) return send(res, 400, { error: 'new owner must be a member of the group' });
        await storage.transferRoomOwner(roomId, target);
        await markRoomChanged(roomId, r.members);
        return send(res, 200, { owner: target });
      }
      if (memberOne && req.method === 'DELETE') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(memberOne[1]);
        const target = decodeURIComponent(memberOne[2]);
        const r = await storage.getRoom(roomId);
        if (!r || !r.members.includes(target)) return send(res, 404, { error: 'not a member' });
        if (target === r.owner) return send(res, 409, { error: 'owner cannot be removed' });
        const isOwner = d.userId === r.owner;
        const isSelf = d.userId === target;
        if (!isOwner && !isSelf) {
          if (!hasCapability(r, d.userId, 'remove_members')) return send(res, 403, { error: 'missing capability: remove_members' });
          if (r.admins.includes(target)) return send(res, 403, { error: 'an admin cannot remove another admin' });
        }
        await storage.removeRoomMember(roomId, target); // при повторном добавлении история начинается заново
        await markRoomChanged(roomId, r.members);       // прежние участники, включая удалённого, узнают об изменении
        return send(res, 200, { ok: true });
      }

      // Правка и удаление сообщения. Автор правит своё сообщение; удаляет своё или чужое по праву.
      // Настройки группы: название (право edit_group_name) и видимость (право edit_group_settings).
      const settingsRoute = p.match(/^\/rooms\/([^/]+)\/settings$/);
      if (settingsRoute && req.method === 'POST') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(settingsRoute[1]);
        const r = await storage.getRoom(roomId);
        if (!r || !r.members.includes(d.userId)) return send(res, 403, { error: 'not a member' });
        const checked = validateRoomSettings(body);
        if (checked.error) return send(res, 400, { error: checked.error });
        if (checked.value.name !== undefined && !hasCapability(r, d.userId, 'edit_group_name')) {
          return send(res, 403, { error: 'missing capability: edit_group_name' });
        }
        if ((checked.value.visibility !== undefined || checked.value.joinPolicy !== undefined) && !hasCapability(r, d.userId, 'edit_group_settings')) {
          return send(res, 403, { error: 'missing capability: edit_group_settings' });
        }
        await storage.setRoomSettings(roomId, checked.value);
        // Группа стала приватной: заявки на вступление больше не действуют.
        if (checked.value.visibility === 'private') await storage.clearJoinRequests(roomId);
        return send(res, 200, { ok: true, ...checked.value });
      }

      // Отметка чтения: участник сообщает, до какого сообщения он дочитал. Позиция не откатывается.
      const readRoute = p.match(/^\/rooms\/([^/]+)\/read$/);
      if (readRoute && req.method === 'POST') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(readRoute[1]);
        const r = await storage.getRoom(roomId);
        if (!r || !r.members.includes(d.userId)) return send(res, 403, { error: 'not a member' });
        const idMatch = /^\$(\d+)$/.exec(String(body.upTo ?? ''));
        if (!idMatch) return send(res, 400, { error: 'upTo must look like $123' });
        const seq = Number(idMatch[1]);
        if (seq > (await storage.roomLastSeq(roomId))) return send(res, 400, { error: 'upTo is ahead of the room' });
        await storage.setReadUpTo(roomId, d.userId, seq);
        return send(res, 200, { ok: true });
      }

      // Поиск публичных групп: только публичные, только по названию, без списка участников.
      if (req.method === 'GET' && p === '/rooms/search') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const q = (new URL(req.url, 'http://localhost').searchParams.get('q') ?? '').trim();
        if (q.length < 2 || q.length > 50) return send(res, 400, { error: 'q must be 2 to 50 characters' });
        return send(res, 200, { rooms: await storage.searchPublicRooms(q, 20) });
      }

      // Вступление в публичную группу: свободно или по заявке, как настроено в группе.
      const joinRoute = p.match(/^\/rooms\/([^/]+)\/join$/);
      if (joinRoute && req.method === 'POST') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(joinRoute[1]);
        const r = await storage.getRoom(roomId);
        // Приватная группа для постороннего не существует: тот же ответ, что и для несуществующей.
        if (!r || r.visibility !== 'public') return send(res, 404, { error: 'room not found' });
        if (r.members.includes(d.userId)) return send(res, 409, { error: 'already a member' });
        if (r.joinPolicy === 'open') {
          await storage.addRoomMember(roomId, d.userId);
          await markRoomChanged(roomId, (await storage.getRoom(roomId)).members);
          return send(res, 200, { status: 'joined' });
        }
        await storage.createJoinRequest(roomId, d.userId, now());
        return send(res, 200, { status: 'requested' });
      }

      // Заявки на вступление: видят и решают те, у кого есть право приглашать.
      const requestsRoute = p.match(/^\/rooms\/([^/]+)\/requests$/);
      if (requestsRoute && req.method === 'GET') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(requestsRoute[1]);
        const r = await storage.getRoom(roomId);
        if (!r || !hasCapability(r, d.userId, 'invite_members')) return send(res, 403, { error: 'missing capability: invite_members' });
        return send(res, 200, { requests: await storage.listJoinRequests(roomId) });
      }

      const decideRoute = p.match(/^\/rooms\/([^/]+)\/requests\/([^/]+)\/(approve|reject)$/);
      if (decideRoute && req.method === 'POST') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(decideRoute[1]);
        const target = decodeURIComponent(decideRoute[2]);
        const r = await storage.getRoom(roomId);
        if (!r || !hasCapability(r, d.userId, 'invite_members')) return send(res, 403, { error: 'missing capability: invite_members' });
        if (!(await storage.deleteJoinRequest(roomId, target))) return send(res, 404, { error: 'no such request' });
        if (decideRoute[3] === 'reject') return send(res, 200, { status: 'rejected' });
        await storage.addRoomMember(roomId, target);
        await markRoomChanged(roomId, (await storage.getRoom(roomId)).members);
        return send(res, 200, { status: 'joined' });
      }

      // Ссылка-приглашение и QR-код с этой ссылкой. Право создавать и отзывать — invite_members.
      const invitesRoute = p.match(/^\/rooms\/([^/]+)\/invites$/);
      if (invitesRoute && req.method === 'POST') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(invitesRoute[1]);
        const r = await storage.getRoom(roomId);
        if (!r || !hasCapability(r, d.userId, 'invite_members')) return send(res, 403, { error: 'missing capability: invite_members' });
        const checked = validateInviteOptions(body);
        if (checked.error) return send(res, 400, { error: checked.error });
        const token = createInviteToken();
        const invite = {
          inviteId: createInviteId(), tokenHash: hashInviteToken(token), createdBy: d.userId, createdAt: now(),
          expiresAt: now() + checked.value.expiresInHours * 60 * 60 * 1000, maxUses: checked.value.maxUses,
          uses: 0, requiresApproval: checked.value.requiresApproval, revoked: false,
        };
        await storage.createInvite(roomId, invite);
        const url = `${publicUrl}/invite/${token}`;
        const qrSvg = await QRCode.toString(url, { type: 'svg', margin: 1 });
        return send(res, 200, { inviteId: invite.inviteId, url, qrSvg, expiresAt: invite.expiresAt, maxUses: invite.maxUses, requiresApproval: invite.requiresApproval });
      }
      if (invitesRoute && req.method === 'GET') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(invitesRoute[1]);
        const r = await storage.getRoom(roomId);
        if (!r || !hasCapability(r, d.userId, 'invite_members')) return send(res, 403, { error: 'missing capability: invite_members' });
        // Сами ссылки здесь не показываются: токен известен только в момент создания.
        return send(res, 200, { invites: await storage.listInvites(roomId) });
      }

      const revokeRoute = p.match(/^\/rooms\/([^/]+)\/invites\/([^/]+)\/revoke$/);
      if (revokeRoute && req.method === 'POST') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(revokeRoute[1]);
        const r = await storage.getRoom(roomId);
        if (!r || !hasCapability(r, d.userId, 'invite_members')) return send(res, 403, { error: 'missing capability: invite_members' });
        if (!(await storage.revokeInvite(roomId, decodeURIComponent(revokeRoute[2])))) return send(res, 404, { error: 'no such invite' });
        return send(res, 200, { ok: true });
      }

      // Вступление по ссылке. Токен передаётся в теле, а не в адресе: адрес попадает в журналы.
      if (req.method === 'POST' && p === '/invites/join') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const token = typeof body.token === 'string' ? body.token : '';
        if (!token) return send(res, 400, { error: 'token required' });
        const invite = await storage.findInviteByTokenHash(hashInviteToken(token));
        // Неверная, отозванная, истёкшая и исчерпанная ссылка выглядят одинаково.
        if (!invite || !inviteUsable(invite, now())) return send(res, 404, { error: 'invite is not valid' });
        const r = await storage.getRoom(invite.roomId);
        if (!r) return send(res, 404, { error: 'invite is not valid' });
        if (r.members.includes(d.userId)) return send(res, 409, { error: 'already a member' });
        if (invite.requiresApproval) {
          if (await storage.hasJoinRequest(invite.roomId, d.userId)) return send(res, 200, { status: 'requested' });
          if (!(await storage.useInvite(invite.inviteId, now()))) return send(res, 404, { error: 'invite is not valid' });
          await storage.createJoinRequest(invite.roomId, d.userId, now());
          return send(res, 200, { status: 'requested' });
        }
        if (!(await storage.useInvite(invite.inviteId, now()))) return send(res, 404, { error: 'invite is not valid' });
        await storage.addRoomMember(invite.roomId, d.userId);
        await markRoomChanged(invite.roomId, (await storage.getRoom(invite.roomId)).members);
        return send(res, 200, { status: 'joined', roomId: invite.roomId });
      }

            // Группы MLS: эпоха группы, коммиты и приветственные сообщения. Коммит принимается только от актуальной эпохи.
            const mlsCommitRoute = p.match(/^\/mls\/groups\/([^/]+)\/commits$/);
            if (mlsCommitRoute && req.method === 'POST') {
              const d = await authed(req);
              if (!d) return send(res, 401, { error: 'unauthorized' });
              const roomId = decodeURIComponent(mlsCommitRoute[1]);
              const r = await storage.getRoom(roomId);
              if (!r) return send(res, 404, { error: 'group not found' });
              if (!r.members.includes(d.userId)) return send(res, 403, { error: 'not a member' });
              const checked = parseCommitRequest(body);
              if (checked.error) return send(res, 400, { error: checked.error });
              const { adds, removes } = checked.value.changes;
              const isOwner = d.userId === r.owner;
              for (const t of removes) {
                if (!r.members.includes(t)) return send(res, 400, { error: `not a member: ${t}` });
                if (t === r.owner) return send(res, 409, { error: 'owner cannot be removed' });
                if (t !== d.userId && !isOwner) {
                  if (!hasCapability(r, d.userId, 'remove_members')) return send(res, 403, { error: 'missing capability: remove_members' });
                  if (r.admins.includes(t)) return send(res, 403, { error: 'an admin cannot remove another admin' });
                }
              }
              for (const u of adds) {
                if (r.members.includes(u)) return send(res, 409, { error: `already a member: ${u}` });
                if (!isOwner && !hasCapability(r, d.userId, 'invite_members')) return send(res, 403, { error: 'missing capability: invite_members' });
                if (!(await storage.hasAccount(u))) return send(res, 400, { error: `unknown account: ${u}` });
                if (!checked.value.welcomes.some((w) => w.userId === u)) return send(res, 400, { error: `added member needs a welcome: ${u}` });
              }
              const pendingDevices = await storage.mlsPendingRemovalDevices(roomId);
        for (const device of checked.value.changes.removeDevices) {
          if (!pendingDevices.includes(device)) return send(res, 400, { error: `device is not waiting for removal in this group: ${device}` });
        }
        const afterMembers = new Set([...r.members.filter((m) => !removes.includes(m)), ...adds]);
              for (const w of checked.value.welcomes) {
                if (!afterMembers.has(w.userId)) return send(res, 400, { error: 'welcome recipient is not a member' });
                if (!(await storage.hasAccount(w.userId))) return send(res, 400, { error: 'welcome recipient is not a known account' });
              }
              const result = await storage.mlsApplyCommit(roomId, checked.value.epoch, { senderId: d.userId, commit: checked.value.commit, welcomes: checked.value.welcomes, changes: checked.value.changes }, now());
              if (result.ok && (adds.length > 0 || removes.length > 0)) await markRoomChanged(roomId, [...new Set([...r.members, ...adds])]);
              if (!result.ok && result.reason === 'already-member') return send(res, 409, { error: 'already a member' });
              if (!result.ok && result.reason === 'recipient') return send(res, 400, { error: 'welcome recipient is not a known account' });
              if (!result.ok) return send(res, 409, { error: 'epoch is outdated', currentEpoch: result.epoch });
              return send(res, 200, { epoch: result.epoch });
            }
            // Сообщение группы MLS: сервер проверяет группу и эпоху в открытом заголовке, шифротекст не читает.
            const mlsMessageRoute = p.match(/^\/mls\/groups\/([^/]+)\/messages$/);
            if (mlsMessageRoute && req.method === 'POST') {
              const d = await authed(req);
              if (!d) return send(res, 401, { error: 'unauthorized' });
              const roomId = decodeURIComponent(mlsMessageRoute[1]);
              const r = await storage.getRoom(roomId);
              if (!r) return send(res, 404, { error: 'group not found' });
              if (!r.members.includes(d.userId)) return send(res, 403, { error: 'not a member' });
              const kind = body.kind ?? 'text';
              if (!MESSAGE_KINDS.includes(kind)) return send(res, 400, { error: 'kind must be text, sticker or gif' });
              if (body.forwarded !== undefined && typeof body.forwarded !== 'boolean') return send(res, 400, { error: 'forwarded must be a boolean' });
              if (!hasCapability(r, d.userId, 'send_messages')) return send(res, 403, { error: 'missing capability: send_messages' });
              if (kind !== 'text' && !hasCapability(r, d.userId, 'send_stickers_gifs')) return send(res, 403, { error: 'missing capability: send_stickers_gifs' });
              if (body.forwarded === true && !hasCapability(r, d.userId, 'forward_messages')) return send(res, 403, { error: 'missing capability: forward_messages' });
              const checked = parseApplicationRequest(body);
              if (checked.error) return send(res, 400, { error: checked.error });
              const header = readPrivateMessageHeader(checked.value);
              if (header.error) return send(res, 400, { error: header.error });
              if (!header.value.groupId.equals(Buffer.from(roomId, 'utf8'))) return send(res, 400, { error: 'message belongs to another group' });
              // Повтор с тем же clientMessageId возвращает первое сообщение. Одинаковые запросы, пришедшие одновременно,
              // закрыты резервированием: строку с идентификатором вставляет только один запрос, остальные ждут или получают готовый ответ.
              const clientMessageId = body.clientMessageId;
              if (clientMessageId !== undefined) {
                if (typeof clientMessageId !== 'string' || !/^[A-Za-z0-9_-]{1,64}$/.test(clientMessageId)) return send(res, 400, { error: 'clientMessageId: 1-64 letters, digits, _ or -' });
                const known = await storage.findClientMessage(roomId, d.userId, clientMessageId);
                if (known !== null) return send(res, 200, { event_id: `$${known}` });
              }
              const epoch = await storage.mlsGroupEpoch(roomId);
              if (epoch === 0) return send(res, 409, { error: 'group has no epoch yet' });
              if (header.value.epoch !== epoch) return send(res, 409, { error: 'epoch is outdated', currentEpoch: epoch });
              let reserved = false;
              if (clientMessageId !== undefined) {
                const claim = await storage.reserveClientMessage(roomId, d.userId, clientMessageId);
                if (claim.state === 'done') return send(res, 200, { event_id: `$${claim.seq}` });
                if (claim.state === 'pending') return send(res, 409, { error: 'a message with this clientMessageId is being sent: retry later' });
                reserved = true;
              }
              let seq;
              try {
                seq = await storage.appendRoomEvent(roomId, d.userId, 'm.room.encrypted', { mls: body.message, kind, forwarded: body.forwarded === true }, now());
              } catch (error) {
                if (reserved) await storage.releaseClientMessage(roomId, d.userId, clientMessageId);
                throw error;
              }
              if (reserved) await storage.completeClientMessage(roomId, d.userId, clientMessageId, seq);
              return send(res, 200, { event_id: `$${seq}` });
            }
            if (req.method === 'GET' && p === '/mls/removals') {
              const d = await authed(req);
              if (!d) return send(res, 401, { error: 'unauthorized' });
              return send(res, 200, { removals: await storage.mlsPendingRemovalsFor(d.userId) });
            }
            const mlsEpochRoute = p.match(/^\/mls\/groups\/([^/]+)\/epoch$/);
            if (mlsEpochRoute && req.method === 'GET') {
              const d = await authed(req);
              if (!d) return send(res, 401, { error: 'unauthorized' });
              const roomId = decodeURIComponent(mlsEpochRoute[1]);
              const r = await storage.getRoom(roomId);
              if (!r) return send(res, 404, { error: 'group not found' });
              if (!r.members.includes(d.userId)) return send(res, 403, { error: 'not a member' });
              return send(res, 200, { epoch: await storage.mlsGroupEpoch(roomId) });
            }
            const mlsCommitsRoute = p.match(/^\/mls\/groups\/([^/]+)\/commits$/);
            if (mlsCommitsRoute && req.method === 'GET') {
              const d = await authed(req);
              if (!d) return send(res, 401, { error: 'unauthorized' });
              const roomId = decodeURIComponent(mlsCommitsRoute[1]);
              const r = await storage.getRoom(roomId);
              if (!r) return send(res, 404, { error: 'group not found' });
              if (!r.members.includes(d.userId)) return send(res, 403, { error: 'not a member' });
              const since = Number(new URL(req.url, 'http://local').searchParams.get('since') ?? 0);
              if (!Number.isSafeInteger(since) || since < 0) return send(res, 400, { error: 'since must be a non-negative integer' });
              const rows = await storage.mlsCommitsSince(roomId, since, 100);
              return send(res, 200, { commits: rows.map((c) => ({ epoch: c.epoch, sender: c.senderId, commit: c.commit.toString('base64') })) });
            }
            if (req.method === 'GET' && p === '/mls/welcomes') {
              const d = await authed(req);
              if (!d) return send(res, 401, { error: 'unauthorized' });
              const rows = await storage.mlsPendingWelcomes(d.userId, d.deviceId);
              return send(res, 200, { welcomes: rows.map((w) => ({ id: w.id, roomId: w.roomId, epoch: w.epoch, welcome: w.welcome.toString('base64') })) });
            }
            const mlsAckRoute = p.match(/^\/mls\/welcomes\/(\d+)\/ack$/);
            if (mlsAckRoute && req.method === 'POST') {
              const d = await authed(req);
              if (!d) return send(res, 401, { error: 'unauthorized' });
              if (!(await storage.mlsAckWelcome(Number(mlsAckRoute[1]), d.userId, d.deviceId, now()))) return send(res, 404, { error: 'welcome not found' });
              return send(res, 200, { ok: true });
            }
      // Ключевые пакеты MLS. Устройство загружает свои пакеты; другой участник получает по одному на устройство.
      if (req.method === 'POST' && p === '/mls/key-packages') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const checked = parseKeyPackages(body?.packages);
        if (checked.error) return send(res, 400, { error: checked.error });
        const unused = await storage.mlsAvailableCount(d.userId, d.deviceId, now());
        if (unused + checked.value.length > MLS_UNUSED_MAX) return send(res, 409, { error: `a device can keep at most ${MLS_UNUSED_MAX} unused key packages` });
        await storage.mlsStoreKeyPackages(d.userId, d.deviceId, checked.value, now());
        return send(res, 200, { stored: checked.value.length, available: unused + checked.value.length });
      }
      if (req.method === 'GET' && p === '/mls/key-packages/count') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        return send(res, 200, { available: await storage.mlsAvailableCount(d.userId, d.deviceId, now()) });
      }
      // Резервный ключевой пакет: один на устройство, заменяется при новой загрузке, не расходуется.
      if (req.method === 'POST' && p === '/mls/key-packages/last-resort') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const checked = parseKeyPackages([body?.package]);
        if (checked.error) return send(res, 400, { error: checked.error });
        await storage.mlsStoreLastResort(d.userId, d.deviceId, checked.value[0], now());
        return send(res, 200, { stored: true });
      }
      const mlsClaim = p.match(/^\/mls\/key-packages\/([^/]+)$/);
      if (mlsClaim && req.method === 'GET') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const rate = await checkRate('mlsClaimPerAccount', d.userId);
        if (!rate.allowed) return send(res, 429, { error: 'too many key requests, try later' });
        const claimed = await storage.mlsClaimKeyPackages(decodeURIComponent(mlsClaim[1]), now());
        return send(res, 200, { packages: claimed.map((c) => ({ deviceId: c.deviceId, package: c.package.toString('base64') })) });
      }

      // Оформление группы. Право — edit_group_appearance.
      const appearanceRoute = p.match(/^\/rooms\/([^/]+)\/appearance$/);
      if (appearanceRoute && req.method === 'POST') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(appearanceRoute[1]);
        const r = await storage.getRoom(roomId);
        if (!r || !r.members.includes(d.userId)) return send(res, 403, { error: 'not a member' });
        if (!hasCapability(r, d.userId, 'edit_group_appearance')) return send(res, 403, { error: 'missing capability: edit_group_appearance' });
        const checked = validateAppearance(body);
        if (checked.error) return send(res, 400, { error: checked.error });
        const expectedKind = { avatarAssetId: 'avatar', coverAssetId: 'cover', backgroundAssetId: 'background' };
        for (const [key, kind] of Object.entries(expectedKind)) {
          const id = checked.value[key];
          if (id === undefined || id === null) continue;
          const asset = await storage.getRoomAsset(roomId, id);
          if (!asset) return send(res, 400, { error: `${key}: asset not found in this group` });
          if (asset.kind !== kind) return send(res, 400, { error: `${key}: asset has kind ${asset.kind}` });
        }
        await storage.setRoomAppearance(roomId, checked.value);
        return send(res, 200, { ok: true, ...checked.value });
      }

      // Загрузка файла оформления или стикера. Формат и тип проверяются по содержимому.
      const assetsRoute = p.match(/^\/rooms\/([^/]+)\/assets$/);
      if (assetsRoute && req.method === 'POST') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(assetsRoute[1]);
        const r = await storage.getRoom(roomId);
        if (!r || !r.members.includes(d.userId)) return send(res, 403, { error: 'not a member' });
        if (!hasCapability(r, d.userId, 'edit_group_appearance')) return send(res, 403, { error: 'missing capability: edit_group_appearance' });
        const checked = validateAssetUpload(body, r);
        if (checked.error) return send(res, checked.status ?? 400, { error: checked.error });
        const file = checked.value;
        if (file.kind === 'sticker') {
          const stickers = await storage.listRoomStickers(roomId);
          if (stickers.length >= MAX_STICKERS_PER_GROUP) return send(res, 409, { error: `a group can have at most ${MAX_STICKERS_PER_GROUP} stickers` });
          if (stickers.some((s) => s.shortcode === file.shortcode)) return send(res, 409, { error: 'shortcode is already used in this group' });
        }
        const assetId = createAssetId();
        await storage.addRoomAsset(roomId, { assetId, roomId, kind: file.kind, contentType: file.contentType, encrypted: file.encrypted, data: file.data, shortcode: file.shortcode, createdBy: d.userId, createdAt: now() });
        return send(res, 200, { assetId, kind: file.kind, size: file.data.length });
      }

      // Файлы, которые ждут замены под текущий вид группы (с правом на оформление).
      const pendingRoute = p.match(/^\/rooms\/([^/]+)\/assets\/pending$/);
      if (pendingRoute && req.method === 'GET') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(pendingRoute[1]);
        const r = await storage.getRoom(roomId);
        if (!r || !hasCapability(r, d.userId, 'edit_group_appearance')) return send(res, 403, { error: 'missing capability: edit_group_appearance' });
        const assets = (await storage.listRoomAssets(roomId)).filter((a) => !assetMatchesVisibility(a, r));
        return send(res, 200, { assets: assets.map(({ assetId, kind, encrypted, shortcode }) => ({ assetId, kind, encrypted, shortcode })) });
      }

      // Чтение файла: в публичной группе — любому вошедшему, в приватной — только участнику.
      // Для постороннего приватный файл не существует.
      const assetRoute = p.match(/^\/rooms\/([^/]+)\/assets\/([^/]+)$/);
      if (assetRoute && req.method === 'GET') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(assetRoute[1]);
        const r = await storage.getRoom(roomId);
        if (!r || !assetVisibleTo(r, d.userId)) return send(res, 404, { error: 'asset not found' });
        const asset = await storage.getRoomAsset(roomId, decodeURIComponent(assetRoute[2]));
        if (!asset) return send(res, 404, { error: 'asset not found' });
        if (!assetMatchesVisibility(asset, r)) return send(res, 409, { error: 'file must be replaced to match the group visibility' });
        return send(res, 200, { assetId: asset.assetId, kind: asset.kind, contentType: asset.contentType, encrypted: asset.encrypted, dataBase64: asset.data.toString('base64') });
      }
      // Замена файла тем же идентификатором: так приватная группа получает зашифрованную версию.
      if (assetRoute && req.method === 'PUT') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(assetRoute[1]);
        const assetId = decodeURIComponent(assetRoute[2]);
        const r = await storage.getRoom(roomId);
        if (!r || !hasCapability(r, d.userId, 'edit_group_appearance')) return send(res, 403, { error: 'missing capability: edit_group_appearance' });
        const current = await storage.getRoomAsset(roomId, assetId);
        if (!current) return send(res, 404, { error: 'asset not found' });
        const checked = validateAssetUpload(body, r);
        if (checked.error) return send(res, checked.status ?? 400, { error: checked.error });
        if (checked.value.kind !== current.kind) return send(res, 400, { error: `kind must stay ${current.kind}` });
        await storage.replaceRoomAsset(roomId, assetId, { contentType: checked.value.contentType, encrypted: checked.value.encrypted, data: checked.value.data });
        return send(res, 200, { assetId, encrypted: checked.value.encrypted, size: checked.value.data.length });
      }
      if (assetRoute && req.method === 'DELETE') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(assetRoute[1]);
        const r = await storage.getRoom(roomId);
        if (!r || !hasCapability(r, d.userId, 'edit_group_appearance')) return send(res, 403, { error: 'missing capability: edit_group_appearance' });
        if (!(await storage.deleteRoomAsset(roomId, decodeURIComponent(assetRoute[2])))) return send(res, 404, { error: 'asset not found' });
        return send(res, 200, { ok: true });
      }

      // Собственные стикеры группы: список видят участники.
      const stickersRoute = p.match(/^\/rooms\/([^/]+)\/stickers$/);
      if (stickersRoute && req.method === 'GET') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(stickersRoute[1]);
        const r = await storage.getRoom(roomId);
        if (!r || !r.members.includes(d.userId)) return send(res, 403, { error: 'not a member' });
        return send(res, 200, { stickers: (await storage.listRoomStickers(roomId)).filter((s) => assetMatchesVisibility(s, r)) });
      }

      const eventAction = p.match(/^\/rooms\/([^/]+)\/events\/([^/]+)\/(redact|edit)$/);
      if (eventAction && req.method === 'POST') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(eventAction[1]);
        const eventId = decodeURIComponent(eventAction[2]);
        const idMatch = /^\$(\d+)$/.exec(eventId);
        if (!idMatch) return send(res, 400, { error: 'event id must look like $123' });
        const seq = Number(idMatch[1]);
        const r = await storage.getRoom(roomId);
        if (!r || !r.members.includes(d.userId)) return send(res, 403, { error: 'not a member' });
        const target = await storage.findRoomEvent(roomId, seq);
        if (!target) return send(res, 404, { error: 'event not found' });
        if (target.type === 'm.room.redacted') return send(res, 409, { error: 'event already deleted' });
        if (eventAction[3] === 'redact') {
          const need = target.sender === d.userId ? 'delete_own_messages' : 'delete_any_messages';
          if (!hasCapability(r, d.userId, need)) return send(res, 403, { error: `missing capability: ${need}` });
          if (deleteWindowClosed(target, now())) return send(res, 403, { error: 'delete window closed: 24 hours after sending' });
          if (readByOthers(r, target)) return send(res, 403, { error: 'delete window closed: the message was read' });
          await storage.redactRoomEvent(roomId, seq, d.userId, now());
          return send(res, 200, { ok: true });
        }
        // Правка в группе MLS пока не проверяется по эпохе: её запрещаем, пока не будет отдельного контракта.
        if (target.sender !== d.userId) return send(res, 403, { error: 'only the author can edit a message' });
        if (!hasCapability(r, d.userId, 'edit_own_messages')) return send(res, 403, { error: 'missing capability: edit_own_messages' });
        if (editWindowClosed(target, now())) return send(res, 403, { error: 'edit window closed: 24 hours after sending' });
        if (body.type !== 'm.room.encrypted') return send(res, 400, { error: 'this server accepts only encrypted events' });
        const checkedEdit = parseApplicationRequest(body);
        if (checkedEdit.error) return send(res, 400, { error: checkedEdit.error });
        const editHeader = readPrivateMessageHeader(checkedEdit.value);
        if (editHeader.error) return send(res, 400, { error: editHeader.error });
        if (!editHeader.value.groupId.equals(Buffer.from(roomId, 'utf8'))) return send(res, 400, { error: 'message belongs to another group' });
        const editEpoch = await storage.mlsGroupEpoch(roomId);
        if (editEpoch === 0) return send(res, 409, { error: 'group has no epoch yet' });
        if (editHeader.value.epoch !== editEpoch) return send(res, 409, { error: 'epoch is outdated', currentEpoch: editEpoch });
        const newSeq = await storage.appendRoomEvent(roomId, d.userId, 'm.room.encrypted.replace', { replaces: `$${seq}`, payload: { mls: body.message } }, now());
        return send(res, 200, { event_id: `$${newSeq}` });
      }

      const roomRoute = p.match(/^\/rooms\/([^/]+)\/events$/);
      if (roomRoute && req.method === 'POST') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        if (body.type !== 'm.room.encrypted') {
          return send(res, 400, { error: 'this server accepts only encrypted events' });
        }
        const roomId = decodeURIComponent(roomRoute[1]);
        const r = await storage.getRoom(roomId);
        if (!r || !r.members.includes(d.userId)) return send(res, 403, { error: 'not a member' });
        // Вид сообщения и признак пересылки клиент объявляет сам: внутри шифротекста сервер их не видит.
        return send(res, 409, { error: 'messages must be sent through /mls/groups/:id/messages' });
        const kind = body.kind ?? 'text';
        if (!MESSAGE_KINDS.includes(kind)) return send(res, 400, { error: 'kind must be text, sticker or gif' });
        if (body.forwarded !== undefined && typeof body.forwarded !== 'boolean') return send(res, 400, { error: 'forwarded must be a boolean' });
        if (!hasCapability(r, d.userId, 'send_messages')) return send(res, 403, { error: 'missing capability: send_messages' });
        if (kind !== 'text' && !hasCapability(r, d.userId, 'send_stickers_gifs')) return send(res, 403, { error: 'missing capability: send_stickers_gifs' });
        if (body.forwarded === true && !hasCapability(r, d.userId, 'forward_messages')) return send(res, 403, { error: 'missing capability: forward_messages' });
        const seq = await storage.appendRoomEvent(roomId, d.userId, body.type, body.content, now());
        return send(res, 200, { event_id: `$${seq}` });
      }
      if (roomRoute && req.method === 'GET') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const roomId = decodeURIComponent(roomRoute[1]);
        const r = await storage.getRoom(roomId);
        if (!r || !r.members.includes(d.userId)) return send(res, 403, { error: 'not a member' });
        // Только события после вступления участника (C-07). Внутренний номер наружу не отдаём.
        const since = r.joinedSeq[d.userId] ?? 0;
        const rows = await storage.roomEventRows(roomId, since);
        return send(res, 200, { events: rows.map(({ seq, ...rest }) => rest) });
      }

      // ---------- восстановление после кражи ----------
      if (req.method === 'POST' && p === '/recovery/start') {
        // Один и тот же ответ, есть такой аккаунт или нет: не раскрываем, кто зарегистрирован.
        const startEmail = normalizeEmail(body.email);
        const userId = body.userId ?? (startEmail ? await storage.userIdByEmail(startEmail) : null);
        // Лимит на запросы восстановления с одного адреса, в том числе по несуществующим аккаунтам: SMS и письма стоят денег (D5).
        const perAddress = await checkRate('recoveryPerAddress', clientIp(req));
        if (!perAddress.allowed) return send(res, 429, { error: 'too many recovery requests from this address', retryAt: new Date(perAddress.retryAt).toISOString() });
        if (await storage.hasAccount(userId)) {
          const phone = await storage.phoneGet(userId);
          // Аккаунт без подтверждённого телефона: восстановление по почте (решение владельца). Одна почта и окно 48 часов.
          // Аккаунт с привязкой Google или Apple восстанавливается входом через провайдера: кода здесь нет.
          if (!phone.verified && (await storage.providerLinksOf(userId)).length === 0) {
            const emailCode = String(randomInt(0, 1_000_000)).padStart(6, '0');
            const issued = await storage.recoveryUpdate(userId, (r) => {
              const out = requestCode(r, { nowMs: now(), codeHash: recoveryCodeHash(userId, emailCode), linkHash: null });
              const next = out.issued ? confirmLink(out.next, { nowMs: now(), linkOk: true }).next : out.next;
              return { next, result: out.issued };
            });
            if (issued) {
              await mailTo(await confirmationEmail(userId), 'Код восстановления InOne',
                `Код: ${emailCode}. Код действует час. Вход откроется только через 48 часов после смены пароля. Если это не вы, ничего не вводите.`);
              await mail(userId, 'Запрошено восстановление InOne',
                'Кто-то запросил восстановление доступа. Код отправлен на запасную или основную почту. Если это не вы, ничего не делайте и проверьте устройства.');
              await alertDevices(userId, { kind: 'recovery_started' });
            }
          }
          // Восстановление возможно только при подтверждённом телефоне (D5).
          // SMS на номер не чаще заданного за сутки: лишние запросы не шлют SMS.
          if (phone.verified && (await checkRate('smsPerPhone', phone.phone)).allowed) {
            const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
            const token = randomBytes(24).toString('base64url');
            const issued = await storage.recoveryUpdate(userId, (r) => {
              const out = requestCode(r, { nowMs: now(), codeHash: recoveryCodeHash(userId, code), linkHash: recoveryLinkHash(userId, token) });
              return { next: out.next, result: out.issued };
            });
            if (issued) {
              // D5: код приходит по SMS, подтверждение — ссылкой из письма. Это два разных канала.
              await smsSender.send(phone.phone, `Код: ${code}. Код восстановления InOne действует час. Если это не вы — не вводите его.`);
              await mail(userId, 'Подтверждение восстановления',
                `Чтобы подтвердить восстановление, откройте ссылку: ${publicUrl}/recovery/confirm?user=${encodeURIComponent(userId)}&token=${token}. Ссылка действует час. Если это не вы — не открывайте её.`);
              await alertDevices(userId, { kind: 'recovery_started' });
            }
          }
        }
        return send(res, 202, { ok: true });
      }

      if (req.method === 'GET' && p === '/recovery/confirm') {
        // Открытие ссылки из письма ничего не меняет: предпросмотр почты не подтвердит восстановление (D5).
        const userId = url.searchParams.get('user') ?? '';
        const token = url.searchParams.get('token') ?? '';
        if (!token) return send(res, 400, { error: 'token required' });
        res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
        return res.end(htmlPage('Подтверждение восстановления', `
<p>Нажмите кнопку, чтобы подтвердить, что восстановление запросили вы. Код из SMS вводится в приложении.</p>
<form method="post" action="/recovery/confirm">
<input type="hidden" name="user" value="${escapeHtml(userId)}">
<input type="hidden" name="token" value="${escapeHtml(token)}">
<button type="submit">Подтвердить восстановление</button>
</form>`));
      }

      if (req.method === 'POST' && p === '/recovery/confirm') {
        const userId = String(body.user ?? '');
        const token = String(body.token ?? '');
        const outcome = await storage.recoveryUpdate(userId, (r) => {
          const out = confirmLink(r, { nowMs: now(), linkOk: token !== '' && !!r.reqLinkHash && sameHex(recoveryLinkHash(userId, token), r.reqLinkHash) });
          return { next: out.next, result: out.outcome };
        });
        const status = outcome === 'ok' ? 200 : outcome === 'expired' ? 410 : outcome === 'none' ? 404 : 403;
        const message = {
          ok: 'Подтверждено. Вернитесь в приложение и введите код из SMS.',
          expired: 'Ссылка истекла. Запросите восстановление заново.',
          none: 'Активного восстановления нет.',
          wrong: 'Ссылка неверная.',
        }[outcome];
        if (isForm) {
          res.writeHead(status, { 'content-type': 'text/html; charset=utf-8' });
          return res.end(htmlPage('Подтверждение восстановления', `<p>${escapeHtml(message)}</p>`));
        }
        const error = { expired: 'recovery expired', none: 'no active recovery', wrong: 'wrong link' }[outcome];
        return send(res, status, error ? { error } : { ok: true });
      }

      if (req.method === 'POST' && p === '/recovery/cancel-by-code') {
        // Отмена восстановления кодом из письма: нужна, если устройств для отмены нет (решение владельца).
        const email = normalizeEmail(body.email);
        const perEmail = await checkRate('recoveryCancelPerEmail', email);
        if (!perEmail.allowed) return send(res, 429, { error: 'too many attempts, try later' });
        const userId = await storage.userIdByEmail(email);
        const r = userId ? await storage.recoveryGet(userId) : null;
        const saved = userId ? await storage.recoveryCancelGet(userId) : null;
        const code = typeof body.code === 'string' ? body.code : '';
        const ok = !!r && windowOpen(r, now()) && !!saved && now() <= saved.expiresAt && sameHex(recoveryCancelHash(userId, code), saved.codeHash);
        if (!ok) return send(res, 403, { error: 'wrong code' });
        // Вернуть прежний пароль и отключить устройства, появившиеся после запроса. PIN не меняется.
        if (r.windowPreviousHash) await storage.setPasswordHash(userId, r.windowPreviousHash);
        for (const rec of await storage.devicesOfUser(userId)) {
          if (!rec.revoked && rec.createdAt >= r.windowStartedAt) await revokeDevice(rec);
        }
        await storage.recoveryUpdate(userId, (cur) => ({ next: cancelWindow(cur), result: null }));
        await storage.recoveryCancelClear(userId);
        await mail(userId, 'Восстановление отменено', 'Восстановление отменено кодом отмены. Прежний пароль возвращён.');
        await alertDevices(userId, { kind: 'recovery_cancelled' });
        return send(res, 200, { ok: true });
      }
      if (req.method === 'POST' && p === '/recovery/cancel') {
        const d = await authed(req);
        if (!d) return send(res, 401, { error: 'unauthorized' });
        const r = await storage.recoveryGet(d.userId);
        if (!windowOpen(r, now())) return send(res, 404, { error: 'no active recovery' });
        // Отменить могут только устройства, существовавшие до запроса восстановления (D8).
        if (!(d.createdAt < r.windowStartedAt)) return send(res, 403, { error: 'only devices that existed before the recovery can cancel' });
        // Вернуть прежний пароль и отключить устройства, появившиеся после запроса. PIN не меняется.
        if (r.windowPreviousHash) await storage.setPasswordHash(d.userId, r.windowPreviousHash);
        for (const rec of await storage.devicesOfUser(d.userId)) {
          if (!rec.revoked && rec.createdAt >= r.windowStartedAt) await revokeDevice(rec);
        }
        await storage.recoveryUpdate(d.userId, (cur) => ({ next: cancelWindow(cur), result: null }));
        await mail(d.userId, 'Восстановление отменено',
          'Восстановление отменено с устройства, которое существовало до запроса. Прежний пароль возвращён.');
        await alertDevices(d.userId, { kind: 'recovery_cancelled' });
        return send(res, 200, { ok: true });
      }

      if (req.method === 'POST' && p === '/recovery/complete') {
        const { code, pin, newPassword } = body;
        // Восстановление по почте: адрес вместо идентификатора (без входа идентификатора не знают).
        const userId = body.userId ?? (typeof body.email === 'string' ? await storage.userIdByEmail(normalizeEmail(body.email)) : null);
        if ((await storage.providerLinksOf(userId)).length > 0) return send(res, 409, { error: 'password recovery is disabled for accounts linked to Google or Apple' });
        const check = await storage.recoveryUpdate(userId, (r) => {
          const out = checkCode(r, {
            nowMs: now(),
            codeOk: typeof code === 'string' && !!r.reqCodeHash && sameHex(recoveryCodeHash(userId, code), r.reqCodeHash),
          });
          return { next: out.next, result: out.outcome };
        });
        if (check === 'none') return send(res, 404, { error: 'no active recovery' });
        if (check === 'expired') return send(res, 410, { error: 'recovery expired' });
        if (check === 'unconfirmed') return send(res, 403, { error: 'confirm the link from the email first' });
        if (check === 'wrong' || check === 'locked') {
          if (check === 'locked') await alertDevices(userId, { kind: 'recovery_locked' });
          return send(res, 403, { error: 'wrong code' });
        }
        if (await storage.hasPin(userId)) {
          // PIN не снимается восстановлением (D1): без него восстановление не проходит.
          if (typeof pin !== 'string' || pin === '') return send(res, 403, { error: 'PIN required' });
          const r = await verifyPin(userId, pin);
          if (!r.ok) return pinError(res, r);
        }
        if (typeof newPassword !== 'string' || newPassword.length < MIN_PASSWORD_LENGTH) {
          return send(res, 400, { error: `newPassword required (min ${MIN_PASSWORD_LENGTH} chars)` });
        }
        // Новый пароль сразу (D1). Окно открывается; если уже открыто, не сдвигается (D8).
        const previousHash = await storage.accountHash(userId);
        await storage.setPasswordHash(userId, hashPassword(newPassword));
        const keyResetAt = await storage.recoveryUpdate(userId, (r) => {
          const next = completeRecovery(r, { nowMs: now(), previousHash });
          return { next, result: next.windowKeyResetAt };
        });
        // Код отмены: для аккаунта без устройств тоже. Действует, пока открыто окно (D8).
        const cancelCode = String(randomInt(0, 1_000_000)).padStart(6, '0');
        await storage.recoveryCancelSet(userId, recoveryCancelHash(userId, cancelCode), keyResetAt);
        await mail(userId, 'Восстановление выполнено',
          `Пароль изменён. Вход с новых устройств откроется через 48 часов. Отменить можно с устройства, существовавшего до запроса, или кодом отмены: ${cancelCode}.`);
        await alertDevices(userId, { kind: 'recovery_completed', keyResetAt: new Date(keyResetAt).toISOString() });
        return send(res, 200, { ok: true, keyResetAt: new Date(keyResetAt).toISOString() });
      }

      return send(res, 404, { error: 'not found' });
    } catch (e) {
      if (e.code === 'MAIL_UNAVAILABLE') return send(res, 503, { error: 'mail is temporarily unavailable, try later' });
      return send(res, 500, { error: e.message });
    }
  });

  return {
    server,
    /** Всё, что сервер хранит и получил. Нужно тестам: проверить, что открытого текста здесь нет. */
    dump: async () => JSON.stringify({ ...(await storage.snapshot()), wireLog, outbox }),
    /** Сдвигает часы сервера. Нужно тестам, чтобы проверить задержки 48 часов, 10 минут и блокировок. */
    advance: (ms) => { offset += ms; },
    /** Письма пользователя (в PoC вместо настоящей почты). */
    mailbox: (userId) => outbox.filter((m) => m.to === userId),
    /** Всё, что сервер хранит по беседе. Для теста «украденной копии». */
    roomEvents: async (roomId) => storage.roomEventRows(roomId, 0),
    smsOutbox: (phone) => (smsSender.outbox ?? []).filter((m) => m.phone === phone),
    /** Секреты, которые сервер держит у себя (без исходящих писем). Нужно тестам: токены и коды не лежат открытым текстом. */
    stateSnapshot: async () => JSON.stringify({
      tokens: await storage.tokenHashes(),
      recoveries: await storage.recoveryHashes(),
    }),
    /** Сохранённое значение PIN (должно быть хэшем, а не самим PIN). Нужно тесту хранения. */
    pinStored: (userId) => storage.pinHash(userId),
    /** Сколько раз реально проверяли PIN. Нужно тесту параллельного перебора. */
    pinChecks: () => pinChecks,
  };
}
