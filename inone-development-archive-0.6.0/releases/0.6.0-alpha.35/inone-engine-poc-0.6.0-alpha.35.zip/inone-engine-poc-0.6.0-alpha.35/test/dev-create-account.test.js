// Инструмент создания аккаунта для разработки: проходит обычную регистрацию с фиксированным кодом.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from '../src/server.js';
import { createDevAccount } from '../scripts/dev-create-account.mjs';

const PEPPER = 'test-pepper-0123456789-0123456789-abcd';

test('аккаунт для разработки создаётся обычной регистрацией с фиксированным кодом, пароль не возвращается', async () => {
  const srv = createServer({ registrationMode: 'verified', requirePhone: false, pinPepper: PEPPER, devEmailCode: '000000' });
  await new Promise((resolve) => srv.server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${srv.server.address().port}`;
  try {
    const result = await createDevAccount({ base, email: 'owner@example.test', nickname: 'owner', password: 'СтраннаяФраза-1', code: '000000' });
    assert.equal(result.nickname, 'owner');
    assert.ok(!JSON.stringify(result).includes('СтраннаяФраза-1'), 'пароль не попадает в результат');
    await assert.rejects(createDevAccount({ base, email: 'owner@example.test', nickname: 'owner2', password: 'ДругаяФраза-2', code: '000000' }), /register/);
  } finally {
    await new Promise((r) => srv.server.close(r));
  }
});

test('с неверным кодом аккаунт не создаётся', async () => {
  const srv = createServer({ registrationMode: 'verified', requirePhone: false, pinPepper: PEPPER, devEmailCode: '000000' });
  await new Promise((resolve) => srv.server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${srv.server.address().port}`;
  try {
    await assert.rejects(createDevAccount({ base, email: 'bad@example.test', nickname: 'badcode', password: 'СтраннаяФраза-1', code: '111111' }), /confirm/);
  } finally {
    await new Promise((r) => srv.server.close(r));
  }
});
